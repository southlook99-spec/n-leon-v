let currentService = 'course';
const today = new Date().toISOString().split('T')[0];

document.addEventListener('DOMContentLoaded', function() {
  const dateInput = document.getElementById('date');
  if (dateInput) {
    dateInput.value = today;
    dateInput.min = today;
  }
});

function setService(service) {
  currentService = service;
  const tabCourse = document.getElementById('tab-course');
  const tabDispo = document.getElementById('tab-dispo');
  if (tabCourse) tabCourse.classList.toggle('active', service === 'course');
  if (tabDispo) tabDispo.classList.toggle('active', service === 'disposition');
  
  const isDispo = service === 'disposition';
  const fieldDropoff = document.getElementById('field-dropoff');
  const dispoFields = document.getElementById('dispo-fields');
  const lblPickup = document.getElementById('lbl-pickup');
  const estLabel = document.getElementById('est-label');
  const estKm = document.getElementById('est-km');
  const estFormula = document.getElementById('est-formula');
  const estPrice = document.getElementById('est-price');
  const btnSubmit = document.getElementById('btn-submit');
  
  if (fieldDropoff) fieldDropoff.style.display = isDispo ? 'none' : 'block';
  if (dispoFields) dispoFields.style.display = isDispo ? 'block' : 'none';
  if (lblPickup) lblPickup.innerText = isDispo ? 'Point de prise en charge' : 'Adresse de prise en charge (Départ)';
  
  if (isDispo) {
    if (estLabel) estLabel.innerText = 'Durée souhaitée';
    const durationVal = document.getElementById('duration') ? document.getElementById('duration').value : '2';
    if (estKm) estKm.innerText = durationVal + ' heures';
    if (estFormula) estFormula.innerText = 'Tarif personnalisé fixé directement avec N LEON';
    if (estPrice) estPrice.innerText = 'Sur devis';
    if (btnSubmit) btnSubmit.innerText = 'Envoyer ma demande de devis →';
  } else {
    if (btnSubmit) btnSubmit.innerText = 'Confirmer la réservation →';
    calculatePrice();
  }
}

function calculatePrice() {
  if (currentService === 'disposition') {
    const durationInput = document.getElementById('duration');
    const d = durationInput ? durationInput.value : '2';
    const estKm = document.getElementById('est-km');
    if (estKm) estKm.innerText = d + ' heures';
    return;
  }
  const pickupInput = document.getElementById('pickup');
  const dropoffInput = document.getElementById('dropoff');
  const estKm = document.getElementById('est-km');
  const estPrice = document.getElementById('est-price');
  
  const p = pickupInput ? pickupInput.value.trim() : '';
  const d = dropoffInput ? dropoffInput.value.trim() : '';
  
  if (p.length < 3 || d.length < 3) {
    if (estKm) estKm.innerText = '—';
    if (estPrice) estPrice.innerText = '—';
    return;
  }
  
  let hash = 0;
  const str = p + d;
  for (let i = 0; i < str.length; i++) hash = (hash + str.charCodeAt(i) * (i + 3)) % 997;
  const km = Math.round((4.5 + (hash % 345) / 10) * 10) / 10;
  const total = 10 + km * 2;
  
  if (estKm) estKm.innerText = km + ' km';
  if (estPrice) estPrice.innerText = total.toFixed(2) + ' €';
}

function submitForm(e) {
  e.preventDefault();
  const nameInput = document.getElementById('name');
  const phoneInput = document.getElementById('phone');
  const name = nameInput ? nameInput.value : 'Client';
  const phone = phoneInput ? phoneInput.value : '';
  const isDispo = currentService === 'disposition';
  
  const modalTitle = document.getElementById('modal-title');
  const modalDesc = document.getElementById('modal-desc');
  const modal = document.getElementById('modal');
  
  if (modalTitle) {
    modalTitle.innerText = isDispo ? 'Demande de devis transmise !' : 'Réservation confirmée !';
  }
  if (modalDesc) {
    modalDesc.innerHTML = isDispo
      ? 'Merci <strong>' + name + '</strong> ! Votre demande a bien été transmise. N LEON vous contactera au ' + phone + ' pour fixer le prix avec vous.'
      : 'Merci <strong>' + name + '</strong> ! Votre trajet en Tesla Model Y Noire Premium est enregistré. Votre chauffeur se tient prêt.';
  }
  if (modal) modal.style.display = 'grid';
}

function closeModal() {
  const modal = document.getElementById('modal');
  if (modal) modal.style.display = 'none';
}

/* Tchat Direct */
function openChat() {
  const backdrop = document.getElementById('chat-backdrop-ovh');
  const win = document.getElementById('chat-window-ovh');
  if (backdrop) backdrop.style.display = 'block';
  if (win) {
    win.style.display = 'flex';
    setTimeout(() => {
      const input = document.getElementById('chat-input-ovh');
      if (input) input.focus();
    }, 100);
  }
}

function closeChat() {
  const backdrop = document.getElementById('chat-backdrop-ovh');
  const win = document.getElementById('chat-window-ovh');
  if (backdrop) backdrop.style.display = 'none';
  if (win) win.style.display = 'none';
}

function handleChatSubmit(e) {
  e.preventDefault();
  const input = document.getElementById('chat-input-ovh');
  if (!input) return;
  const text = input.value.trim();
  if (!text) return;
  
  const body = document.getElementById('chat-body-ovh');
  const b = document.createElement('div');
  b.className = 'msg-bubble msg-client';
  b.innerHTML = text + '<span class="msg-time">' + new Date().toLocaleTimeString('fr-FR', {hour:'2-digit', minute:'2-digit'}) + '</span>';
  if (body) {
    body.appendChild(b);
    body.scrollTop = body.scrollHeight;
  }
  input.value = '';

  setTimeout(() => {
    if (!body) return;
    const reply = document.createElement('div');
    reply.className = 'msg-bubble msg-chauffeur';
    reply.innerHTML = "Merci pour votre message ! Je prends connaissance de votre demande. Pour toute urgence, joignez-moi directement au 06 34 50 70 01.<span class=\"msg-time\">" + new Date().toLocaleTimeString('fr-FR', {hour:'2-digit', minute:'2-digit'}) + "</span>";
    body.appendChild(reply);
    body.scrollTop = body.scrollHeight;
  }, 600);
}

function toggleFaq(el) {
  const a = el.nextElementSibling;
  if (!a) return;
  const isOpen = a.style.display === 'block';
  a.style.display = isOpen ? 'none' : 'block';
  const span = el.querySelector('span');
  if (span) span.innerText = isOpen ? '+' : '−';
}

window.addEventListener('keydown', function(e) {
  if (e.key === 'Escape') {
    closeChat();
    closeModal();
  }
});
