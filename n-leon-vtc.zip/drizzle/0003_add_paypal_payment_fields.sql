ALTER TABLE "bookings" ADD COLUMN "payment_status" text DEFAULT 'unpaid' NOT NULL;--> statement-breakpoint
ALTER TABLE "bookings" ADD COLUMN "payment_provider" text;--> statement-breakpoint
ALTER TABLE "bookings" ADD COLUMN "payment_amount" numeric(10, 2);--> statement-breakpoint
ALTER TABLE "bookings" ADD COLUMN "paypal_order_id" text;--> statement-breakpoint
ALTER TABLE "bookings" ADD COLUMN "paypal_capture_id" text;--> statement-breakpoint
ALTER TABLE "bookings" ADD COLUMN "paid_at" timestamp with time zone;