ALTER TABLE "bookings" DROP COLUMN "starts_at";--> statement-breakpoint
ALTER TABLE "bookings" DROP COLUMN "service_ends_at";--> statement-breakpoint
ALTER TABLE "bookings" DROP COLUMN "blocked_until";--> statement-breakpoint
ALTER TABLE "bookings" DROP COLUMN "buffer_minutes";