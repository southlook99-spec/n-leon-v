ALTER TABLE "bookings" ADD COLUMN "passenger_count" integer;--> statement-breakpoint
ALTER TABLE "bookings" ADD COLUMN "quote_details" text;