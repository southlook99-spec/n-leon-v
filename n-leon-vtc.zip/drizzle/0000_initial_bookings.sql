CREATE TABLE "bookings" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"pickup_address" text NOT NULL,
	"dropoff_address" text NOT NULL,
	"pickup_date" text NOT NULL,
	"pickup_time" text NOT NULL,
	"service_type" text DEFAULT 'course' NOT NULL,
	"duration_hours" integer,
	"vehicle_type" text NOT NULL,
	"estimated_distance" numeric(8, 1) NOT NULL,
	"total_price" numeric(10, 2) NOT NULL,
	"customer_name" text NOT NULL,
	"customer_phone" text NOT NULL,
	"customer_email" text NOT NULL,
	"status" text DEFAULT 'confirmed' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
