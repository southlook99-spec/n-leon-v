import type { Booking } from "@/db/schema";

type PayPalEnvironment = "sandbox" | "live";

type PayPalAmount = {
  currency_code?: string;
  value?: string;
};

type PayPalCapture = {
  id?: string;
  status?: string;
  amount?: PayPalAmount;
};

export type PayPalOrderDetails = {
  id: string;
  status: string;
  purchase_units?: Array<{
    reference_id?: string;
    custom_id?: string;
    amount?: PayPalAmount;
    payments?: {
      captures?: PayPalCapture[];
    };
  }>;
};

type PayPalErrorBody = {
  name?: string;
  message?: string;
  details?: Array<{
    issue?: string;
    description?: string;
  }>;
};

export class PayPalApiError extends Error {
  status: number;
  details?: PayPalErrorBody["details"];
  paypalName?: string;

  constructor(message: string, status: number, body?: PayPalErrorBody) {
    super(message);
    this.name = "PayPalApiError";
    this.status = status;
    this.details = body?.details;
    this.paypalName = body?.name;
  }

  hasIssue(issue: string) {
    return this.details?.some((detail) => detail.issue === issue) ?? false;
  }
}

const tokenCache: { accessToken: string | null; expiresAt: number } = {
  accessToken: null,
  expiresAt: 0,
};

export function getPayPalEnvironment(): PayPalEnvironment {
  return process.env.PAYPAL_ENV === "live" || process.env.PAYPAL_ENV === "production"
    ? "live"
    : "sandbox";
}

export function getPayPalClientId() {
  return process.env.PAYPAL_CLIENT_ID ?? process.env.NEXT_PUBLIC_PAYPAL_CLIENT_ID ?? null;
}

function getPayPalClientSecret() {
  return process.env.PAYPAL_CLIENT_SECRET ?? null;
}

export function isPayPalConfigured() {
  return Boolean(getPayPalClientId() && getPayPalClientSecret());
}

export function getPayPalPublicConfig() {
  return {
    enabled: isPayPalConfigured(),
    clientId: getPayPalClientId(),
    environment: getPayPalEnvironment(),
    currency: "EUR" as const,
  };
}

function getPayPalApiBaseUrl() {
  return getPayPalEnvironment() === "live"
    ? "https://api-m.paypal.com"
    : "https://api-m.sandbox.paypal.com";
}

async function parsePayPalResponse(response: Response) {
  const text = await response.text();
  if (!text) return null;

  try {
    return JSON.parse(text) as Record<string, unknown>;
  } catch {
    return null;
  }
}

async function getPayPalAccessToken() {
  const clientId = getPayPalClientId();
  const clientSecret = getPayPalClientSecret();

  if (!clientId || !clientSecret) {
    throw new PayPalApiError("PayPal n’est pas encore configuré sur le serveur.", 503);
  }

  if (tokenCache.accessToken && tokenCache.expiresAt > Date.now() + 30_000) {
    return tokenCache.accessToken;
  }

  const credentials = Buffer.from(`${clientId}:${clientSecret}`).toString("base64");
  const response = await fetch(`${getPayPalApiBaseUrl()}/v1/oauth2/token`, {
    method: "POST",
    headers: {
      Authorization: `Basic ${credentials}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: new URLSearchParams({ grant_type: "client_credentials" }),
    cache: "no-store",
  });
  const payload = (await parsePayPalResponse(response)) as
    | { access_token?: string; expires_in?: number; message?: string }
    | null;

  if (!response.ok || !payload?.access_token) {
    throw new PayPalApiError(
      payload?.message || "Impossible de s’authentifier auprès de PayPal.",
      response.status,
    );
  }

  tokenCache.accessToken = payload.access_token;
  tokenCache.expiresAt = Date.now() + (payload.expires_in ?? 300) * 1000;
  return payload.access_token;
}

async function payPalRequest<T>(path: string, init: RequestInit = {}): Promise<T> {
  const accessToken = await getPayPalAccessToken();
  const response = await fetch(`${getPayPalApiBaseUrl()}${path}`, {
    ...init,
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
      Prefer: "return=representation",
      ...(init.headers ?? {}),
    },
    cache: "no-store",
  });
  const payload = (await parsePayPalResponse(response)) as PayPalErrorBody | T | null;

  if (!response.ok) {
    const errorBody = (payload ?? {}) as PayPalErrorBody;
    throw new PayPalApiError(
      errorBody.message || "PayPal a refusé la demande de paiement.",
      response.status,
      errorBody,
    );
  }

  return payload as T;
}

function formatPayPalAmount(value: string | number) {
  return Number(value).toFixed(2);
}

export async function createPayPalOrder(booking: Booking) {
  const amount = formatPayPalAmount(booking.totalPrice);
  const serviceLabel =
    booking.serviceType === "disposition"
      ? `Mise à disposition chauffeur privé — ${booking.durationHours ?? 1} heure(s)`
      : "Course / transfert chauffeur privé";

  return payPalRequest<PayPalOrderDetails>("/v2/checkout/orders", {
    method: "POST",
    headers: {
      "PayPal-Request-Id": `nleon-create-${booking.id}`,
    },
    body: JSON.stringify({
      intent: "CAPTURE",
      purchase_units: [
        {
          reference_id: booking.id,
          custom_id: booking.id,
          description: `${serviceLabel} — N LEON`,
          amount: {
            currency_code: "EUR",
            value: amount,
            breakdown: {
              item_total: {
                currency_code: "EUR",
                value: amount,
              },
            },
          },
          items: [
            {
              name: "Réservation chauffeur privé N LEON",
              description: serviceLabel,
              quantity: "1",
              unit_amount: {
                currency_code: "EUR",
                value: amount,
              },
            },
          ],
        },
      ],
      application_context: {
        brand_name: "N LEON",
        locale: "fr-FR",
        shipping_preference: "NO_SHIPPING",
        user_action: "PAY_NOW",
      },
    }),
  });
}

export async function getPayPalOrder(orderId: string) {
  return payPalRequest<PayPalOrderDetails>(`/v2/checkout/orders/${encodeURIComponent(orderId)}`, {
    method: "GET",
  });
}

export async function capturePayPalOrder(orderId: string, bookingId: string) {
  try {
    return await payPalRequest<PayPalOrderDetails>(
      `/v2/checkout/orders/${encodeURIComponent(orderId)}/capture`,
      {
        method: "POST",
        headers: {
          "PayPal-Request-Id": `nleon-capture-${bookingId}-${orderId}`,
        },
        body: JSON.stringify({}),
      },
    );
  } catch (error) {
    if (error instanceof PayPalApiError && error.hasIssue("ORDER_ALREADY_CAPTURED")) {
      return getPayPalOrder(orderId);
    }
    throw error;
  }
}

export function getPayPalCapture(order: PayPalOrderDetails) {
  return order.purchase_units?.[0]?.payments?.captures?.[0] ?? null;
}
