import { eq } from "drizzle-orm";
import { db } from "@/db";
import { bookings } from "@/db/schema";

export const dynamic = "force-dynamic";

type RouteContext = {
  params: Promise<{ bookingId: string }>;
};

export async function POST(_request: Request, { params }: RouteContext) {
  try {
    const { bookingId } = await params;

    const [booking] = await db
      .select()
      .from(bookings)
      .where(eq(bookings.id, bookingId))
      .limit(1);

    if (!booking) {
      return Response.json({ message: "Réservation introuvable." }, { status: 404 });
    }

    if (booking.paymentStatus === "paid") {
      return Response.json({ message: "Cette réservation est déjà payée." }, { status: 409 });
    }

    if (booking.status !== "pending_payment") {
      return Response.json({
        bookingId: booking.id,
        totalPrice: Number(booking.totalPrice),
        paymentStatus: booking.paymentStatus,
        status: booking.status,
        message: "Votre réservation est confirmée. Le paiement sera réglé plus tard.",
      });
    }

    const [updatedBooking] = await db
      .update(bookings)
      .set({
        status: "confirmed",
        paymentStatus: "due_on_service",
        paymentProvider: "pay_later",
      })
      .where(eq(bookings.id, booking.id))
      .returning({
        id: bookings.id,
        totalPrice: bookings.totalPrice,
        paymentStatus: bookings.paymentStatus,
        status: bookings.status,
      });

    return Response.json({
      bookingId: updatedBooking.id,
      totalPrice: Number(updatedBooking.totalPrice),
      paymentStatus: updatedBooking.paymentStatus,
      status: updatedBooking.status,
      message: "Votre réservation est confirmée. Le paiement sera réglé plus tard.",
    });
  } catch (error) {
    console.error("Unable to confirm pay-later booking", error);
    return Response.json(
      { message: "Impossible de confirmer cette réservation pour le moment." },
      { status: 500 },
    );
  }
}
