import { db } from "@/db";
import { bookings } from "@/db/schema";

export const dynamic = "force-dynamic";

type BookingPayload = {
  serviceType?: unknown;
  paymentPreference?: unknown;
  durationHours?: unknown;
  passengerCount?: unknown;
  quoteDetails?: unknown;
  pickupAddress?: unknown;
  dropoffAddress?: unknown;
  pickupDate?: unknown;
  pickupTime?: unknown;
  estimatedDistance?: unknown;
  customerName?: unknown;
  customerPhone?: unknown;
  customerEmail?: unknown;
};

const isFilledText = (value: unknown) =>
  typeof value === "string" && value.trim().length > 1 && value.trim().length <= 300;

const isQuoteDetailsValid = (value: string) => value.length >= 10 && value.length <= 1000;

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as BookingPayload;
    const serviceType =
      body.serviceType === "disposition" || body.serviceType === "course" ? body.serviceType : null;
    const paymentPreference = body.paymentPreference === "paypal" ? "paypal" : "pay_later";
    const isDisposition = serviceType === "disposition";
    const durationHours = Number(body.durationHours);
    const passengerCount = Number(body.passengerCount);
    const quoteDetails = typeof body.quoteDetails === "string" ? body.quoteDetails.trim() : "";
    const estimatedDistance = Number(body.estimatedDistance);
    const pickupAddress = typeof body.pickupAddress === "string" ? body.pickupAddress.trim() : "";
    const dropoffAddress = typeof body.dropoffAddress === "string" ? body.dropoffAddress.trim() : "";
    const pickupDate = typeof body.pickupDate === "string" ? body.pickupDate.trim() : "";
    const pickupTime = typeof body.pickupTime === "string" ? body.pickupTime.trim() : "";
    const customerName = typeof body.customerName === "string" ? body.customerName.trim() : "";
    const customerPhone = typeof body.customerPhone === "string" ? body.customerPhone.trim() : "";
    const customerEmail = typeof body.customerEmail === "string" ? body.customerEmail.trim().toLowerCase() : "";

    const isCourseValid =
      serviceType === "course" &&
      isFilledText(dropoffAddress) &&
      Number.isFinite(estimatedDistance) &&
      estimatedDistance >= 1 &&
      estimatedDistance <= 500;
    const isDispositionValid =
      isDisposition &&
      Number.isInteger(durationHours) &&
      durationHours >= 1 &&
      durationHours <= 24 &&
      Number.isInteger(passengerCount) &&
      passengerCount >= 1 &&
      passengerCount <= 4 &&
      isQuoteDetailsValid(quoteDetails);

    if (
      !serviceType ||
      !isFilledText(pickupAddress) ||
      !isFilledText(pickupDate) ||
      !isFilledText(pickupTime) ||
      (!isCourseValid && !isDispositionValid) ||
      !isFilledText(customerName) ||
      !isFilledText(customerPhone) ||
      !isFilledText(customerEmail) ||
      !customerEmail.includes("@")
    ) {
      return Response.json({ message: "Veuillez vérifier les informations de réservation." }, { status: 400 });
    }

    const roundedDistance = isDisposition ? 0 : Math.round(estimatedDistance * 10) / 10;
    const storedDurationHours = isDisposition ? durationHours : null;
    const storedPassengerCount = isDisposition ? passengerCount : null;
    const storedQuoteDetails = isDisposition ? quoteDetails : null;
    const storedDropoffAddress = isDisposition
      ? "Mise à disposition sur devis — programme transmis par le client"
      : dropoffAddress;
    const totalPrice = isDisposition ? 0 : 10 + roundedDistance * 2;
    const isPayPalPayment = !isDisposition && paymentPreference === "paypal";

    const [booking] = await db
      .insert(bookings)
      .values({
        pickupAddress,
        dropoffAddress: storedDropoffAddress,
        pickupDate,
        pickupTime,
        serviceType,
        durationHours: storedDurationHours,
        passengerCount: storedPassengerCount,
        quoteDetails: storedQuoteDetails,
        vehicleType: "berline",
        estimatedDistance: roundedDistance.toFixed(1),
        totalPrice: totalPrice.toFixed(2),
        customerName,
        customerPhone,
        customerEmail,
        paymentStatus: isDisposition
          ? "quote_to_define"
          : isPayPalPayment
            ? "awaiting_payment"
            : "due_on_service",
        paymentProvider: isDisposition ? null : isPayPalPayment ? "paypal" : "pay_later",
        paymentAmount: isDisposition ? null : totalPrice.toFixed(2),
        status: isDisposition ? "quote_requested" : isPayPalPayment ? "pending_payment" : "confirmed",
      })
      .returning({
        id: bookings.id,
        totalPrice: bookings.totalPrice,
        paymentStatus: bookings.paymentStatus,
        status: bookings.status,
      });

    return Response.json({
      bookingId: booking.id,
      totalPrice: Number(booking.totalPrice),
      paymentStatus: booking.paymentStatus,
      status: booking.status,
      message: isDisposition
        ? "Votre demande de mise à disposition est envoyée. N LEON vous contactera pour fixer le prix avec vous."
        : isPayPalPayment
          ? "Votre réservation est créée. Finalisez le paiement PayPal pour la confirmer."
          : "Votre réservation est confirmée. Le paiement sera réglé plus tard.",
    });
  } catch (error) {
    console.error("Unable to create booking", error);
    return Response.json(
      { message: "Une erreur est survenue. Veuillez réessayer dans un instant." },
      { status: 500 },
    );
  }
}
