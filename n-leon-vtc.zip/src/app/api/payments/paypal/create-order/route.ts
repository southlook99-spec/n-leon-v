import { eq } from "drizzle-orm";
import { db } from "@/db";
import { bookings } from "@/db/schema";
import { createPayPalOrder, isPayPalConfigured, PayPalApiError } from "@/lib/paypal";

export const dynamic = "force-dynamic";

type CreateOrderPayload = {
  bookingId?: unknown;
};

export async function POST(request: Request) {
  try {
    if (!isPayPalConfigured()) {
      return Response.json(
        { message: "Le paiement PayPal n’est pas encore configuré. Ajoutez les identifiants PayPal dans Vercel." },
        { status: 503 },
      );
    }

    const body = (await request.json()) as CreateOrderPayload;
    const bookingId = typeof body.bookingId === "string" ? body.bookingId.trim() : "";

    if (!bookingId) {
      return Response.json({ message: "La référence de réservation est manquante." }, { status: 400 });
    }

    const [booking] = await db
      .select()
      .from(bookings)
      .where(eq(bookings.id, bookingId))
      .limit(1);

    if (!booking) {
      return Response.json({ message: "Réservation introuvable." }, { status: 404 });
    }

    if (booking.serviceType === "disposition") {
      return Response.json(
        {
          message:
            "Les mises à disposition font l’objet d’un prix personnalisé. Contactez N LEON au 06 34 50 70 01 pour fixer le prix.",
        },
        { status: 409 },
      );
    }

    if (booking.paymentStatus === "paid") {
      return Response.json({ message: "Cette réservation est déjà payée." }, { status: 409 });
    }

    if (booking.status !== "pending_payment") {
      return Response.json(
        { message: "Cette réservation n’est plus en attente de paiement PayPal." },
        { status: 409 },
      );
    }

    const order = await createPayPalOrder(booking);

    await db
      .update(bookings)
      .set({
        paymentProvider: "paypal",
        paymentStatus: "paypal_order_created",
        paymentAmount: booking.totalPrice,
        paypalOrderId: order.id,
      })
      .where(eq(bookings.id, booking.id));

    return Response.json({ id: order.id, status: order.status });
  } catch (error) {
    console.error("Unable to create PayPal order", error);
    return Response.json(
      {
        message:
          error instanceof PayPalApiError
            ? error.message
            : "Impossible de créer la commande PayPal pour le moment.",
      },
      { status: error instanceof PayPalApiError ? error.status : 502 },
    );
  }
}
