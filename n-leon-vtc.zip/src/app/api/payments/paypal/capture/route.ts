import { eq } from "drizzle-orm";
import { db } from "@/db";
import { bookings } from "@/db/schema";
import {
  capturePayPalOrder,
  getPayPalCapture,
  isPayPalConfigured,
  PayPalApiError,
} from "@/lib/paypal";

export const dynamic = "force-dynamic";

type CapturePayload = {
  bookingId?: unknown;
  orderID?: unknown;
  orderId?: unknown;
};

export async function POST(request: Request) {
  try {
    if (!isPayPalConfigured()) {
      return Response.json(
        { message: "Le paiement PayPal n’est pas encore configuré. Ajoutez les identifiants PayPal dans Vercel." },
        { status: 503 },
      );
    }

    const body = (await request.json()) as CapturePayload;
    const bookingId = typeof body.bookingId === "string" ? body.bookingId.trim() : "";
    const orderIdValue = body.orderID ?? body.orderId;
    const orderId = typeof orderIdValue === "string" ? orderIdValue.trim() : "";

    if (!bookingId || !orderId) {
      return Response.json(
        { message: "La réservation ou la commande PayPal est manquante." },
        { status: 400 },
      );
    }

    const [booking] = await db
      .select()
      .from(bookings)
      .where(eq(bookings.id, bookingId))
      .limit(1);

    if (!booking) {
      return Response.json({ message: "Réservation introuvable." }, { status: 404 });
    }

    if (booking.paymentStatus === "paid" && booking.paypalCaptureId) {
      return Response.json({
        bookingId: booking.id,
        totalPrice: Number(booking.totalPrice),
        paymentStatus: booking.paymentStatus,
        paymentProvider: booking.paymentProvider,
        captureId: booking.paypalCaptureId,
        paidAt: booking.paidAt?.toISOString(),
        message: "Paiement déjà confirmé.",
      });
    }

    if (booking.paypalOrderId && booking.paypalOrderId !== orderId) {
      return Response.json(
        { message: "La commande PayPal ne correspond pas à cette réservation." },
        { status: 409 },
      );
    }

    const order = await capturePayPalOrder(orderId, booking.id);
    const capture = getPayPalCapture(order);
    const capturedAmount = Number(capture?.amount?.value);
    const expectedAmount = Number(booking.totalPrice);

    if (
      order.status !== "COMPLETED" ||
      !capture?.id ||
      capture.status !== "COMPLETED" ||
      capture.amount?.currency_code !== "EUR" ||
      !Number.isFinite(capturedAmount) ||
      Math.abs(capturedAmount - expectedAmount) > 0.009
    ) {
      await db
        .update(bookings)
        .set({ paymentStatus: "payment_verification_failed", paypalOrderId: order.id })
        .where(eq(bookings.id, booking.id));

      return Response.json(
        {
          message:
            "Le paiement n’a pas pu être vérifié automatiquement. Contactez N LEON au 06 34 50 70 01 avant de payer à nouveau.",
        },
        { status: 422 },
      );
    }

    const paidAt = new Date();
    const [updatedBooking] = await db
      .update(bookings)
      .set({
        status: "confirmed",
        paymentStatus: "paid",
        paymentProvider: "paypal",
        paymentAmount: expectedAmount.toFixed(2),
        paypalOrderId: order.id,
        paypalCaptureId: capture.id,
        paidAt,
      })
      .where(eq(bookings.id, booking.id))
      .returning({
        id: bookings.id,
        totalPrice: bookings.totalPrice,
        paymentStatus: bookings.paymentStatus,
        paymentProvider: bookings.paymentProvider,
        paypalCaptureId: bookings.paypalCaptureId,
        paidAt: bookings.paidAt,
      });

    return Response.json({
      bookingId: updatedBooking.id,
      totalPrice: Number(updatedBooking.totalPrice),
      paymentStatus: updatedBooking.paymentStatus,
      paymentProvider: updatedBooking.paymentProvider,
      captureId: updatedBooking.paypalCaptureId,
      paidAt: updatedBooking.paidAt?.toISOString(),
      message: "Paiement PayPal confirmé. Votre réservation est validée.",
    });
  } catch (error) {
    console.error("Unable to capture PayPal order", error);
    return Response.json(
      {
        message:
          error instanceof PayPalApiError
            ? error.message
            : "Impossible de finaliser le paiement PayPal pour le moment.",
      },
      { status: error instanceof PayPalApiError ? error.status : 502 },
    );
  }
}
