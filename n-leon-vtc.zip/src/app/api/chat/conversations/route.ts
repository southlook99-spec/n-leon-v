import { db } from "@/db";
import { chatConversations, chatMessages } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const list = await db
      .select()
      .from(chatConversations)
      .orderBy(desc(chatConversations.lastMessageAt))
      .limit(50);

    return Response.json({ conversations: list });
  } catch (error) {
    console.error("List chat conversations error", error);
    return Response.json({ message: "Erreur serveur" }, { status: 500 });
  }
}
