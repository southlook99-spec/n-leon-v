import { db } from "@/db";
import { chatConversations, chatMessages } from "@/db/schema";
import { asc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const body = (await request.json().catch(() => ({}))) as {
      conversationId?: string;
      clientName?: string;
      clientPhone?: string;
      clientEmail?: string;
    };

    let convId = body.conversationId?.trim();
    let conversation = null;

    if (convId) {
      const [existing] = await db
        .select()
        .from(chatConversations)
        .where(eq(chatConversations.id, convId))
        .limit(1);
      if (existing) {
        conversation = existing;
      }
    }

    if (!conversation) {
      const clientName = body.clientName?.trim() || "Client N LEON";
      const clientPhone = body.clientPhone?.trim() || null;
      const clientEmail = body.clientEmail?.trim() || null;

      const [newConv] = await db
        .insert(chatConversations)
        .values({
          clientName,
          clientPhone,
          clientEmail,
        })
        .returning();

      conversation = newConv;
      convId = newConv.id;

      // Message d'accueil automatique chaleureux de N LEON
      await db.insert(chatMessages).values({
        conversationId: newConv.id,
        sender: "chauffeur",
        content:
          "Bonjour et bienvenue chez N LEON Chauffeur Privé ! Je suis à votre disposition pour vos trajets, réservations ou questions. Comment puis-je vous aider ?",
      });
    }

    const messages = await db
      .select()
      .from(chatMessages)
      .where(eq(chatMessages.conversationId, conversation.id))
      .orderBy(asc(chatMessages.createdAt));

    return Response.json({
      conversation,
      messages,
    });
  } catch (error) {
    console.error("Chat session error", error);
    return Response.json({ message: "Erreur lors de l'accès au tchat" }, { status: 500 });
  }
}
