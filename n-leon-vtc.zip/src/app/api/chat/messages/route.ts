import { db } from "@/db";
import { chatConversations, chatMessages } from "@/db/schema";
import { asc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const conversationId = searchParams.get("conversationId");

    if (!conversationId) {
      return Response.json({ message: "ID de conversation manquant" }, { status: 400 });
    }

    const messages = await db
      .select()
      .from(chatMessages)
      .where(eq(chatMessages.conversationId, conversationId))
      .orderBy(asc(chatMessages.createdAt));

    return Response.json({ messages });
  } catch (error) {
    console.error("Fetch chat messages error", error);
    return Response.json({ message: "Erreur serveur" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = (await request.json().catch(() => ({}))) as {
      conversationId?: string;
      content?: string;
      sender?: "client" | "chauffeur";
      clientName?: string;
      clientPhone?: string;
    };

    const conversationId = body.conversationId?.trim();
    const content = body.content?.trim();
    const sender = body.sender === "chauffeur" ? "chauffeur" : "client";

    if (!conversationId || !content) {
      return Response.json({ message: "Paramètres invalides" }, { status: 400 });
    }

    // Vérifier l'existence de la conversation
    const [conversation] = await db
      .select()
      .from(chatConversations)
      .where(eq(chatConversations.id, conversationId))
      .limit(1);

    if (!conversation) {
      return Response.json({ message: "Conversation introuvable" }, { status: 404 });
    }

    // Insérer le message
    const [newMessage] = await db
      .insert(chatMessages)
      .values({
        conversationId,
        sender,
        content,
        isRead: false,
      })
      .returning();

    // Mettre à jour la date du dernier message et les infos client si fournies
    await db
      .update(chatConversations)
      .set({
        lastMessageAt: new Date(),
        clientName: body.clientName?.trim() || conversation.clientName,
        clientPhone: body.clientPhone?.trim() || conversation.clientPhone,
      })
      .where(eq(chatConversations.id, conversationId));

    // Si c'est le client qui parle et qu'il pose une question urgente ou après 1 message
    const lower = content.toLowerCase();
    let autoReply: string | null = null;

    if (sender === "client") {
      if (lower.includes("tarif") || lower.includes("prix") || lower.includes("combien")) {
        autoReply =
          "Nos courses démarrent à 10 € de forfait de base + 2,00 €/km en Berline. Vous pouvez calculer votre trajet précis dans le formulaire ci-dessus ou me joindre au 06 34 50 70 01.";
      } else if (lower.includes("dispo") || lower.includes("urgent") || lower.includes("maintenant") || lower.includes("ce soir")) {
        autoReply =
          "Bien reçu ! Si votre demande est immédiate, n'hésitez pas à m'appeler directement au 06 34 50 70 01 pour une confirmation instantanée.";
      } else if (lower.includes("aeroport") || lower.includes("aéroport") || lower.includes("cdg") || lower.includes("orly")) {
        autoReply =
          "Nous effectuons régulièrement les liaisons vers Roissy CDG, Orly et Beauvais avec accueil pancarte et suivi de vol. Indiquez-moi votre horaire de vol ou réservez directement ci-dessus.";
      }
    }

    if (autoReply) {
      await db.insert(chatMessages).values({
        conversationId,
        sender: "chauffeur",
        content: autoReply,
      });
    }

    const allMessages = await db
      .select()
      .from(chatMessages)
      .where(eq(chatMessages.conversationId, conversationId))
      .orderBy(asc(chatMessages.createdAt));

    return Response.json({
      message: newMessage,
      messages: allMessages,
    });
  } catch (error) {
    console.error("Post chat message error", error);
    return Response.json({ message: "Erreur d'envoi" }, { status: 500 });
  }
}
