import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
};

export const metadata: Metadata = {
  title: "N LEON | Chauffeur Privé de Luxe · Cergy & Île-de-France",
  description:
    "L'excellence à chaque trajet. Chauffeur privé VTC à Cergy, Saint-Ouen-l’Aumône et toute l’Île-de-France en Tesla Model Y Noire Premium (cuir noir, jantes 19″, vitres arrière surteintées). Transferts aéroports, gares et mise à disposition.",
  keywords: [
    "chauffeur privé cergy",
    "vtc cergy",
    "vtc saint ouen l'aumone",
    "tesla model y vtc",
    "transfert aeroport roissy cdg orly",
    "chauffeur prive ile de france",
    "N LEON chauffeur",
  ],
  authors: [{ name: "N LEON" }],
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fr" className="scroll-smooth">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;0,700;1,400;1,600&family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="bg-[#050608] text-[#f7f2e9] antialiased selection:bg-[#d7b577] selection:text-[#0a0b0e]">
        {children}
      </body>
    </html>
  );
}
