import { boolean, integer, numeric, pgTable, text, timestamp, uuid } from "drizzle-orm/pg-core";

export const bookings = pgTable("bookings", {
  id: uuid("id").defaultRandom().primaryKey(),
  pickupAddress: text("pickup_address").notNull(),
  dropoffAddress: text("dropoff_address").notNull(),
  pickupDate: text("pickup_date").notNull(),
  pickupTime: text("pickup_time").notNull(),
  serviceType: text("service_type").notNull().default("course"),
  durationHours: integer("duration_hours"),
  passengerCount: integer("passenger_count"),
  quoteDetails: text("quote_details"),
  vehicleType: text("vehicle_type").notNull(),
  estimatedDistance: numeric("estimated_distance", { precision: 8, scale: 1 }).notNull(),
  totalPrice: numeric("total_price", { precision: 10, scale: 2 }).notNull(),
  customerName: text("customer_name").notNull(),
  customerPhone: text("customer_phone").notNull(),
  customerEmail: text("customer_email").notNull(),
  paymentStatus: text("payment_status").notNull().default("unpaid"),
  paymentProvider: text("payment_provider"),
  paymentAmount: numeric("payment_amount", { precision: 10, scale: 2 }),
  paypalOrderId: text("paypal_order_id"),
  paypalCaptureId: text("paypal_capture_id"),
  paidAt: timestamp("paid_at", { withTimezone: true }),
  status: text("status").notNull().default("confirmed"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const chatConversations = pgTable("chat_conversations", {
  id: uuid("id").defaultRandom().primaryKey(),
  clientName: text("client_name").notNull().default("Visiteur"),
  clientPhone: text("client_phone"),
  clientEmail: text("client_email"),
  status: text("status").notNull().default("open"), // open, closed
  lastMessageAt: timestamp("last_message_at", { withTimezone: true }).notNull().defaultNow(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const chatMessages = pgTable("chat_messages", {
  id: uuid("id").defaultRandom().primaryKey(),
  conversationId: uuid("conversation_id").notNull().references(() => chatConversations.id, { onDelete: "cascade" }),
  sender: text("sender").notNull(), // 'client' | 'chauffeur' | 'system'
  content: text("content").notNull(),
  isRead: boolean("is_read").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type Booking = typeof bookings.$inferSelect;
export type NewBooking = typeof bookings.$inferInsert;

export type ChatConversation = typeof chatConversations.$inferSelect;
export type NewChatConversation = typeof chatConversations.$inferInsert;

export type ChatMessage = typeof chatMessages.$inferSelect;
export type NewChatMessage = typeof chatMessages.$inferInsert;
