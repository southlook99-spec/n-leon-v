"use client";

import { CreditCard, LoaderCircle, ShieldCheck } from "lucide-react";
import { useEffect, useRef, useState } from "react";

export type PayPalPaymentSuccess = {
  bookingId: string;
  totalPrice: number;
  paymentStatus: string;
  paymentProvider?: string | null;
  captureId?: string | null;
  paidAt?: string;
  message?: string;
};

type PayPalCheckoutProps = {
  bookingId: string;
  clientId: string;
  environment: "sandbox" | "live";
  onSuccess: (result: PayPalPaymentSuccess) => void;
};

type PayPalButtonsInstance = {
  render: (container: HTMLElement) => Promise<void>;
  close?: () => Promise<void>;
};

type PayPalButtonsConfig = {
  fundingSource?: string;
  style?: Record<string, string>;
  createOrder: () => Promise<string>;
  onApprove: (data: { orderID: string }) => Promise<void>;
  onCancel?: () => void;
  onError?: (error: unknown) => void;
};

type PayPalSdk = {
  FUNDING: {
    PAYPAL: string;
    CARD: string;
  };
  Buttons: (config: PayPalButtonsConfig) => PayPalButtonsInstance;
};

declare global {
  interface Window {
    paypal?: PayPalSdk;
  }
}

let sdkPromise: Promise<PayPalSdk> | null = null;

function loadPayPalSdk(clientId: string) {
  if (typeof window === "undefined") {
    return Promise.reject(new Error("PayPal ne peut être chargé que dans le navigateur."));
  }

  if (window.paypal) return Promise.resolve(window.paypal);
  if (sdkPromise) return sdkPromise;

  sdkPromise = new Promise<PayPalSdk>((resolve, reject) => {
    const params = new URLSearchParams({
      "client-id": clientId,
      currency: "EUR",
      intent: "capture",
      components: "buttons",
      locale: "fr_FR",
    });
    const script = document.createElement("script");
    script.src = `https://www.paypal.com/sdk/js?${params.toString()}`;
    script.async = true;
    script.dataset.paypalSdk = "true";
    script.onload = () => {
      if (window.paypal) {
        resolve(window.paypal);
      } else {
        reject(new Error("Le module PayPal n’a pas pu être initialisé."));
      }
    };
    script.onerror = () => reject(new Error("Impossible de charger PayPal. Vérifiez votre connexion."));
    document.body.appendChild(script);
  });

  return sdkPromise;
}

async function readJsonResponse(response: Response) {
  const payload = (await response.json().catch(() => ({}))) as {
    id?: string;
    message?: string;
  };

  if (!response.ok) {
    throw new Error(payload.message || "Le paiement PayPal n’a pas pu être traité.");
  }

  return payload;
}

export default function PayPalCheckout({
  bookingId,
  clientId,
  environment,
  onSuccess,
}: PayPalCheckoutProps) {
  const paypalContainerRef = useRef<HTMLDivElement>(null);
  const cardContainerRef = useRef<HTMLDivElement>(null);
  const buttonsRef = useRef<PayPalButtonsInstance[]>([]);
  const onSuccessRef = useRef(onSuccess);
  const [isLoading, setIsLoading] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const [message, setMessage] = useState("");

  onSuccessRef.current = onSuccess;

  useEffect(() => {
    let cancelled = false;

    async function renderButtons() {
      setIsLoading(true);
      setMessage("");

      try {
        const paypal = await loadPayPalSdk(clientId);
        if (cancelled || !paypalContainerRef.current || !cardContainerRef.current) return;

        paypalContainerRef.current.innerHTML = "";
        cardContainerRef.current.innerHTML = "";

        const sharedConfig: Omit<PayPalButtonsConfig, "fundingSource" | "style"> = {
          async createOrder() {
            const response = await fetch("/api/payments/paypal/create-order", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ bookingId }),
            });
            const payload = await readJsonResponse(response);
            if (!payload.id) throw new Error("PayPal n’a pas renvoyé de référence de commande.");
            return payload.id;
          },
          async onApprove(data) {
            setIsProcessing(true);
            setMessage("Paiement approuvé, vérification en cours…");

            try {
              const response = await fetch("/api/payments/paypal/capture", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ bookingId, orderID: data.orderID }),
              });
              const payload = (await readJsonResponse(response)) as unknown as PayPalPaymentSuccess;
              onSuccessRef.current(payload);
            } catch (captureError) {
              setIsProcessing(false);
              setMessage(
                captureError instanceof Error
                  ? captureError.message
                  : "Le paiement n’a pas pu être finalisé.",
              );
              throw captureError;
            }
          },
          onCancel() {
            setIsProcessing(false);
            setMessage("Paiement annulé. Vous pouvez réessayer ou choisir de payer plus tard.");
          },
          onError(error) {
            console.error("PayPal checkout error", error);
            setIsProcessing(false);
            setMessage("PayPal n’a pas pu ouvrir le paiement. Veuillez réessayer dans un instant.");
          },
        };

        const paypalButtons = paypal.Buttons({
          ...sharedConfig,
          fundingSource: paypal.FUNDING.PAYPAL,
          style: {
            layout: "vertical",
            color: "gold",
            shape: "rect",
            label: "paypal",
          },
        });
        buttonsRef.current.push(paypalButtons);
        await paypalButtons.render(paypalContainerRef.current);

        try {
          const cardButtons = paypal.Buttons({
            ...sharedConfig,
            fundingSource: paypal.FUNDING.CARD,
            style: {
              layout: "vertical",
              color: "black",
              shape: "rect",
              label: "buynow",
            },
          });
          buttonsRef.current.push(cardButtons);
          await cardButtons.render(cardContainerRef.current);
        } catch (cardError) {
          console.warn("PayPal card button unavailable", cardError);
        }

        if (!cancelled) setIsLoading(false);
      } catch (sdkError) {
        console.error("Unable to render PayPal buttons", sdkError);
        if (!cancelled) {
          setIsLoading(false);
          setMessage(
            sdkError instanceof Error
              ? sdkError.message
              : "Impossible de charger le paiement PayPal.",
          );
        }
      }
    }

    renderButtons();

    return () => {
      cancelled = true;
      buttonsRef.current.forEach((buttons) => {
        buttons.close?.().catch(() => undefined);
      });
      buttonsRef.current = [];
    };
  }, [bookingId, clientId]);

  return (
    <div className="paypal-checkout">
      {isLoading && (
        <p className="paypal-loading">
          <LoaderCircle className="spin" size={17} /> Chargement du paiement sécurisé…
        </p>
      )}

      <div className="paypal-method-label">
        <span>Compte PayPal</span>
      </div>
      <div ref={paypalContainerRef} className="paypal-buttons-container" />

      <div className="paypal-divider"><span>ou</span></div>

      <div className="paypal-method-label">
        <CreditCard size={16} />
        <span>Carte bancaire via PayPal</span>
      </div>
      <div ref={cardContainerRef} className="paypal-buttons-container" />
      <p className="paypal-card-note">Sans obligation d’avoir un compte PayPal, selon éligibilité.</p>

      {isProcessing && (
        <p className="paypal-processing">
          <LoaderCircle className="spin" size={16} /> Ne fermez pas cette fenêtre, paiement en cours…
        </p>
      )}
      {message && <p className="paypal-message" role="alert">{message}</p>}
      {environment === "sandbox" && (
        <p className="paypal-sandbox-note">Mode test PayPal activé : aucun débit réel ne sera effectué.</p>
      )}
      <p className="paypal-secure-note">
        <ShieldCheck size={14} /> Paiement chiffré traité par PayPal. N LEON ne reçoit jamais vos coordonnées bancaires.
      </p>
    </div>
  );
}
