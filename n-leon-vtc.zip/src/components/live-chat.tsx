"use client";

import {
  Check,
  ChevronDown,
  Clock,
  LoaderCircle,
  MessageCircle,
  Phone,
  Send,
  Sparkles,
  User,
  X,
} from "lucide-react";
import { FormEvent, useEffect, useRef, useState } from "react";

type Message = {
  id: string;
  sender: "client" | "chauffeur" | "system";
  content: string;
  createdAt: string;
};

type Conversation = {
  id: string;
  clientName: string;
  clientPhone?: string | null;
  clientEmail?: string | null;
  status: string;
  lastMessageAt: string;
};

const STORAGE_KEY = "nleon_chat_conv_id";

export default function LiveChat() {
  const [isOpen, setIsOpen] = useState(false);
  const [conversation, setConversation] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const [clientName, setClientName] = useState("");
  const [clientPhone, setClientPhone] = useState("");
  const [showIdentityForm, setShowIdentityForm] = useState(false);
  const [isAdminMode, setIsAdminMode] = useState(false);
  const [adminConversations, setAdminConversations] = useState<Conversation[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Initialisation session de tchat
  useEffect(() => {
    const savedId = typeof window !== "undefined" ? localStorage.getItem(STORAGE_KEY) : null;

    async function initSession() {
      setIsLoading(true);
      try {
        const res = await fetch("/api/chat/session", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ conversationId: savedId }),
        });
        const data = (await res.json()) as {
          conversation?: Conversation;
          messages?: Message[];
        };

        if (data.conversation) {
          setConversation(data.conversation);
          setMessages(data.messages || []);
          if (typeof window !== "undefined") {
            localStorage.setItem(STORAGE_KEY, data.conversation.id);
          }
          if (data.conversation.clientName && data.conversation.clientName !== "Client N LEON") {
            setClientName(data.conversation.clientName);
          }
          if (data.conversation.clientPhone) {
            setClientPhone(data.conversation.clientPhone);
          }
        }
      } catch (err) {
        console.error("Failed to init chat", err);
      } finally {
        setIsLoading(false);
      }
    }

    initSession();
  }, []);

  // Polling automatique des messages
  useEffect(() => {
    if (!conversation?.id) return;

    const interval = setInterval(async () => {
      try {
        const res = await fetch(`/api/chat/messages?conversationId=${conversation.id}`);
        const data = (await res.json()) as { messages?: Message[] };
        if (data.messages) {
          setMessages((prev) => {
            if (data.messages && data.messages.length > prev.length) {
              if (!isOpen) {
                setUnreadCount((c) => c + (data.messages!.length - prev.length));
              }
              return data.messages;
            }
            return prev;
          });
        }
      } catch (err) {
        console.error("Chat polling error", err);
      }
    }, 3500);

    return () => clearInterval(interval);
  }, [conversation?.id, isOpen]);

  // Si mode Chauffeur activé, charger la liste des conversations
  useEffect(() => {
    if (!isAdminMode) return;

    async function loadAdminConversations() {
      try {
        const res = await fetch("/api/chat/conversations");
        const data = (await res.json()) as { conversations?: Conversation[] };
        if (data.conversations) {
          setAdminConversations(data.conversations);
        }
      } catch (err) {
        console.error("Failed to load admin convs", err);
      }
    }

    loadAdminConversations();
    const interval = setInterval(loadAdminConversations, 5000);
    return () => clearInterval(interval);
  }, [isAdminMode]);

  // Scroll en bas à chaque message et gestion de la touche Échap pour fermer le tchat
  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
      setUnreadCount(0);

      const handleKeyDown = (e: KeyboardEvent) => {
        if (e.key === "Escape") {
          setIsOpen(false);
        }
      };
      window.addEventListener("keydown", handleKeyDown);
      return () => window.removeEventListener("keydown", handleKeyDown);
    }
  }, [messages, isOpen]);

  async function sendMessage(textToSend?: string) {
    const text = (textToSend ?? inputValue).trim();
    if (!text || !conversation?.id || isSending) return;

    setIsSending(true);
    if (!textToSend) setInputValue("");

    try {
      const res = await fetch("/api/chat/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          conversationId: conversation.id,
          content: text,
          sender: isAdminMode ? "chauffeur" : "client",
          clientName: clientName || undefined,
          clientPhone: clientPhone || undefined,
        }),
      });
      const data = (await res.json()) as { messages?: Message[] };
      if (data.messages) {
        setMessages(data.messages);
      }
    } catch (err) {
      console.error("Error sending message", err);
    } finally {
      setIsSending(false);
    }
  }

  function handleFormSubmit(e: FormEvent) {
    e.preventDefault();
    sendMessage();
  }

  function selectAdminConversation(conv: Conversation) {
    setConversation(conv);
    fetch(`/api/chat/messages?conversationId=${conv.id}`)
      .then((r) => r.json())
      .then((data: { messages?: Message[] }) => {
        if (data.messages) setMessages(data.messages);
      });
  }

  const suggestions = [
    "Tarif pour aéroport Roissy CDG ?",
    "Disponibilité immédiate ?",
    "Devis mise à disposition",
  ];

  return (
    <aside className="live-chat-root" aria-label="Espace de discussion en direct avec N LEON">
      {/* Bulle flottante de déclenchement */}
      {!isOpen && (
        <button
          type="button"
          className="chat-floating-trigger"
          onClick={() => {
            setIsOpen(true);
            setUnreadCount(0);
          }}
          aria-label="Ouvrir le tchat en direct avec N LEON"
        >
          <span className="chat-trigger-avatar">N</span>
          <div className="chat-trigger-text">
            <strong>Tchat en direct</strong>
            <span>N LEON à votre écoute</span>
          </div>
          <span className="chat-online-beacon" title="Chauffeur en ligne" />
          {unreadCount > 0 && <span className="chat-badge">{unreadCount}</span>}
        </button>
      )}

      {/* Fenêtre de tchat */}
      {isOpen && (
        <>
          <div
            className="chat-backdrop"
            onClick={() => setIsOpen(false)}
            aria-hidden="true"
            title="Cliquer pour fermer le tchat"
          />
          <div className="chat-window" role="dialog" aria-label="Discussion avec N LEON">
            {/* Barre de retour rapide en haut */}
            <div className="chat-return-bar">
              <button
                type="button"
                className="chat-return-btn"
                onClick={() => setIsOpen(false)}
                aria-label="Retourner au site"
              >
                ← Retourner au site
              </button>
              <span className="chat-return-hint">Ou appuyez sur Échap</span>
            </div>

            {/* Entête */}
            <header className="chat-header">
            <div className="chat-header-info">
              <div className="chat-header-avatar">N</div>
              <div>
                <div className="chat-header-title">
                  <strong>N LEON · Chauffeur Privé</strong>
                  <span className="chat-status-pill">
                    <i className="status-live-dot" /> En ligne
                  </span>
                </div>
                <p className="chat-header-subtitle">
                  Saint-Ouen-l’Aumône & Île-de-France · Réponse en direct
                </p>
              </div>
            </div>

            <div className="chat-header-actions">
              <a
                href="tel:+33634507001"
                className="chat-call-action"
                title="Appeler directement le chauffeur"
                aria-label="Appeler le chauffeur au 06 34 50 70 01"
              >
                <Phone size={15} />
              </a>
              <button
                type="button"
                className="chat-close-btn"
                onClick={() => setIsOpen(false)}
                aria-label="Fermer la discussion et retourner au site"
                title="Fermer le tchat (retour au site)"
              >
                <X size={18} strokeWidth={2.4} />
                <span style={{ fontSize: "10px", fontWeight: "700" }}>Fermer</span>
              </button>
            </div>
          </header>

          {/* Sélecteur de mode discret (Client / Chauffeur N LEON) */}
          <div className="chat-mode-bar">
            <button
              type="button"
              className={!isAdminMode ? "mode-tab active" : "mode-tab"}
              onClick={() => setIsAdminMode(false)}
            >
              Mode Client
            </button>
            <button
              type="button"
              className={isAdminMode ? "mode-tab active" : "mode-tab"}
              onClick={() => setIsAdminMode(true)}
            >
              Espace Chauffeur N LEON
            </button>
          </div>

          {/* Si mode chauffeur, liste des conversations à sélectionner */}
          {isAdminMode && (
            <div className="admin-conv-selector">
              <span>Conversations ({adminConversations.length}) :</span>
              <div className="admin-conv-list">
                {adminConversations.map((c) => (
                  <button
                    key={c.id}
                    type="button"
                    className={`admin-conv-item ${c.id === conversation?.id ? "selected" : ""}`}
                    onClick={() => selectAdminConversation(c)}
                  >
                    <strong>{c.clientName || "Client"}</strong>
                    <small>{c.clientPhone || "Sans tél"}</small>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Liens réseaux sociaux / messageries directes dans le tchat */}
          <div className="chat-social-strip">
            <span>Messageries directes :</span>
            <div className="chat-social-links">
              <a
                href="https://wa.me/33634507001?text=Bonjour%20N%20LEON,%20je%20souhaite%20r%C3%A9server%20un%20trajet"
                target="_blank"
                rel="noopener noreferrer"
                className="chat-social-pill whatsapp"
                title="WhatsApp N LEON"
              >
                WhatsApp
              </a>
              <a
                href="https://t.me/+33634507001"
                target="_blank"
                rel="noopener noreferrer"
                className="chat-social-pill telegram"
                title="Telegram N LEON"
              >
                Telegram
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="chat-social-pill instagram"
                title="Instagram N LEON"
              >
                Instagram
              </a>
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="chat-social-pill facebook"
                title="Facebook N LEON"
              >
                Facebook
              </a>
            </div>
          </div>

          {/* Bandeau d'assistance rapide téléphone */}
          <div className="chat-quick-call">
            <span>Besoin urgent ?</span>
            <a href="tel:+33634507001">
              <Phone size={12} /> 06 34 50 70 01
            </a>
          </div>

          {/* Corps des messages */}
          <div className="chat-messages-container">
            {isLoading && (
              <div className="chat-loading">
                <LoaderCircle className="spin" size={20} />
                <span>Connexion au tchat…</span>
              </div>
            )}

            {!isLoading && messages.length === 0 && (
              <div className="chat-empty">
                <Sparkles size={24} className="empty-sparkle" />
                <p>Posez votre question directement à N LEON.</p>
                <small>Réservation, disponibilité de dernière minute ou information trajet.</small>
              </div>
            )}

            {messages.map((msg) => {
              const isChauffeur = msg.sender === "chauffeur";
              const timeStr = new Intl.DateTimeFormat("fr-FR", {
                hour: "2-digit",
                minute: "2-digit",
              }).format(new Date(msg.createdAt));

              return (
                <div
                  key={msg.id}
                  className={`chat-bubble-wrap ${isChauffeur ? "from-chauffeur" : "from-client"}`}
                >
                  <div className="chat-bubble">
                    <span className="chat-bubble-sender">
                      {isChauffeur ? "N LEON" : clientName || "Vous"}
                    </span>
                    <p>{msg.content}</p>
                    <span className="chat-bubble-time">{timeStr}</span>
                  </div>
                </div>
              );
            })}
            <div ref={messagesEndRef} />
          </div>

          {/* Suggestions rapides si peu de messages */}
          {!isAdminMode && (
            <div className="chat-suggestions">
              {suggestions.map((s) => (
                <button
                  key={s}
                  type="button"
                  className="chat-sug-chip"
                  onClick={() => sendMessage(s)}
                >
                  {s}
                </button>
              ))}
            </div>
          )}

          {/* Option pour laisser son nom & numéro */}
          {!isAdminMode && (
            <div className="chat-identity-toggle">
              {!showIdentityForm ? (
                <button
                  type="button"
                  onClick={() => setShowIdentityForm(true)}
                  className="identity-toggle-btn"
                >
                  <User size={13} />{" "}
                  {clientName ? `Connecté : ${clientName}` : "Laisser mon nom / téléphone pour être rappelé"}
                </button>
              ) : (
                <div className="identity-form-inline">
                  <input
                    type="text"
                    placeholder="Votre nom"
                    value={clientName}
                    onChange={(e) => setClientName(e.target.value)}
                  />
                  <input
                    type="tel"
                    placeholder="Téléphone"
                    value={clientPhone}
                    onChange={(e) => setClientPhone(e.target.value)}
                  />
                  <button
                    type="button"
                    onClick={() => setShowIdentityForm(false)}
                    aria-label="Valider les coordonnées"
                  >
                    <Check size={14} />
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Zone de saisie */}
          <form className="chat-input-bar" onSubmit={handleFormSubmit}>
            <input
              type="text"
              placeholder={
                isAdminMode
                  ? "Répondre en tant que chauffeur N LEON…"
                  : "Écrivez votre message à N LEON…"
              }
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              disabled={isSending}
            />
            <button
              type="submit"
              disabled={isSending || !inputValue.trim()}
              aria-label="Envoyer le message"
              className="chat-send-btn"
            >
              {isSending ? <LoaderCircle className="spin" size={17} /> : <Send size={17} />}
            </button>
          </form>
        </div>
        </>
      )}
    </aside>
  );
}
