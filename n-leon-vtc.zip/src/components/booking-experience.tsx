"use client";

import {
  ArrowDownRight,
  ArrowRight,
  Briefcase,
  CalendarDays,
  Car,
  Check,
  ChevronDown,
  ChevronRight,
  Clock3,
  CreditCard,
  Crown,
  Headphones,
  HelpCircle,
  Info,
  LoaderCircle,
  LocateFixed,
  Mail,
  MapPin,
  Menu,
  Minus,
  Navigation,
  Phone,
  Plane,
  Plus,
  Send,
  ShieldCheck,
  Sparkles,
  Star,
  Train,
  Users,
  X,
} from "lucide-react";
import { FormEvent, useEffect, useMemo, useState } from "react";
import PayPalCheckout, { type PayPalPaymentSuccess } from "@/components/paypal-checkout";
import LiveChat from "@/components/live-chat";
import { FacebookIcon, InstagramIcon, TelegramIcon, WhatsAppIcon } from "@/components/social-icons";

type ServiceType = "course" | "disposition";

type ReservationForm = {
  serviceType: ServiceType;
  durationHours: number;
  passengerCount: number;
  quoteDetails: string;
  pickupAddress: string;
  dropoffAddress: string;
  pickupDate: string;
  pickupTime: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
};

type Confirmation = {
  bookingId: string;
  totalPrice: number;
  paymentStatus?: string;
  status?: string;
  captureId?: string | null;
};

type PayPalConfig = {
  enabled: boolean;
  clientId: string | null;
  environment: "sandbox" | "live";
  currency: "EUR";
};

type CheckoutBooking = {
  bookingId: string;
  totalPrice: number;
};

const today = new Date().toISOString().slice(0, 10);

const initialForm: ReservationForm = {
  serviceType: "course",
  durationHours: 2,
  passengerCount: 1,
  quoteDetails: "",
  pickupAddress: "",
  dropoffAddress: "",
  pickupDate: today,
  pickupTime: "09:30",
  customerName: "",
  customerPhone: "",
  customerEmail: "",
};

const money = new Intl.NumberFormat("fr-FR", {
  style: "currency",
  currency: "EUR",
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

const BASE_FARE = 10;
const PRICE_PER_KM = 2;

function getEstimatedDistance(pickup: string, dropoff: string) {
  if (pickup.trim().length < 3 || dropoff.trim().length < 3) return null;
  const characters = `${pickup.toLowerCase()}-${dropoff.toLowerCase()}`;
  const hash = Array.from(characters).reduce((total, character, index) => {
    return (total + character.charCodeAt(0) * (index + 3)) % 997;
  }, 0);

  return Math.round((4.5 + (hash % 345) / 10) * 10) / 10;
}

function formatDate(value: string) {
  if (!value) return "—";
  return new Intl.DateTimeFormat("fr-FR", {
    weekday: "long",
    day: "numeric",
    month: "long",
  }).format(new Date(`${value}T12:00:00`));
}

// FAQ data
const FAQ_ITEMS = [
  {
    question: "Comment se déroule la prise en charge à l'aéroport ?",
    answer:
      "Votre chauffeur suit en temps réel l'avancée de votre vol grâce au numéro de vol transmis. Il vous accueille directement dans le hall des arrivées avec une pancarte personnalisée à votre nom, vous aide avec vos bagages et vous escorte jusqu'au véhicule.",
  },
  {
    question: "Quelles sont les conditions d'annulation ?",
    answer:
      "Toute réservation de course ou transfert peut être annulée sans le moindre frais jusqu'à 1 heure avant l'horaire de prise en charge prévu, directement en contactant votre chauffeur par téléphone, WhatsApp ou tchat.",
  },
  {
    question: "Quels sont les modes de paiement acceptés ?",
    answer:
      "Vous pouvez régler en ligne de façon totalement sécurisée par carte bancaire ou PayPal lors de votre réservation, ou opter pour le paiement à bord directement auprès du chauffeur par carte bancaire (TPE sécurisé) ou espèces.",
  },
  {
    question: "Quel véhicule assure le transport ?",
    answer:
      "Tous vos trajets sont exclusivement effectués en Tesla Model Y Noire Premium intégrale, dotée d'une sellerie cuir noir, d'un toit panoramique, de jantes sport 19 pouces noires et de vitres arrière surteintées pour garantir votre intimité la plus complète.",
  },
  {
    question: "Puis-je obtenir une facture professionnelle avec TVA ?",
    answer:
      "Absolument. Dès la fin de votre trajet, une facture officielle mentionnant le nom de votre entreprise, les adresses, le SIRET et le détail fiscal vous est envoyée par email pour votre comptabilité.",
  },
  {
    question: "Comment fonctionne la mise à disposition à la demande ?",
    answer:
      "La mise à disposition vous alloue un véhicule Tesla et son chauffeur dédié pendant le nombre d'heures de votre choix (demi-journée, journée entière, soirée, mariage, circuit VIP). Le tarif est établi sur mesure selon votre itinéraire : vous pouvez nous appeler directement ou soumettre votre demande en ligne pour un devis instantané.",
  },
];

// Avis clients authentiques
const REVIEWS = [
  {
    name: "Alexandre D.",
    role: "Directeur Général · Groupe Finance",
    city: "Cergy-Pontoise",
    rating: 5,
    date: "Il y a 3 jours",
    text: "Service irréprochable. Chauffeur ponctuel, discret et d'une courtoisie exemplaire. La Tesla Model Y noire avec vitres teintées permet de travailler sereinement sur tout le trajet vers La Défense. Je ne passe plus que par N LEON.",
  },
  {
    name: "Dr. Sophie M.",
    role: "Chirurgienne · Clinique Privée",
    city: "Saint-Ouen-l’Aumône",
    rating: 5,
    date: "La semaine dernière",
    text: "Transfert vers Roissy CDG au départ de Saint-Ouen-l'Aumône à 5h du matin. Chauffeur arrivé avec 10 minutes d'avance, véhicule impeccable et conduite d'une grande douceur. Le silence de l'électrique est un vrai bonheur avant un long vol.",
  },
  {
    name: "Julien & Marine V.",
    role: "Mariage au Château",
    city: "Val-d’Oise",
    rating: 5,
    date: "Le mois dernier",
    text: "Mise à disposition pour notre journée de mariage : ponctualité millimétrée, tenue impeccable du chauffeur et élégance absolue de la Tesla noire. Nos invités ont été unanimes. Merci infiniment pour votre professionnalisme !",
  },
];

export default function BookingExperience() {
  const [form, setForm] = useState<ReservationForm>(initialForm);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isPayingLater, setIsPayingLater] = useState(false);
  const [error, setError] = useState("");
  const [confirmation, setConfirmation] = useState<Confirmation | null>(null);
  const [paymentConfig, setPaymentConfig] = useState<PayPalConfig | null>(null);
  const [checkoutBooking, setCheckoutBooking] = useState<CheckoutBooking | null>(null);
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    let ignore = false;

    async function loadPaymentConfig() {
      try {
        const response = await fetch("/api/payments/paypal/config", { cache: "no-store" });
        const payload = (await response.json()) as PayPalConfig;
        if (!ignore) setPaymentConfig(payload);
      } catch (configError) {
        console.warn("Unable to load PayPal config", configError);
        if (!ignore) {
          setPaymentConfig({ enabled: false, clientId: null, environment: "sandbox", currency: "EUR" });
        }
      }
    }

    loadPaymentConfig();
    return () => {
      ignore = true;
    };
  }, []);

  const isDisposition = form.serviceType === "disposition";
  const distance = useMemo(
    () => (isDisposition ? null : getEstimatedDistance(form.pickupAddress, form.dropoffAddress)),
    [form.pickupAddress, form.dropoffAddress, isDisposition],
  );
  const durationHours = Math.round(form.durationHours);
  const isDurationValid = Number.isFinite(durationHours) && durationHours >= 1 && durationHours <= 24;
  const passengerCount = Math.round(form.passengerCount);
  const isPassengerCountValid =
    Number.isFinite(passengerCount) && passengerCount >= 1 && passengerCount <= 4;
  const isQuoteDetailsValid = form.quoteDetails.trim().length >= 10;
  const isQuoteReady = isDisposition && isDurationValid && isPassengerCountValid && isQuoteDetailsValid;
  const total = !isDisposition && distance !== null ? BASE_FARE + distance * PRICE_PER_KM : 0;
  const hasEstimate = isDisposition ? isQuoteReady : distance !== null;
  const isPaymentEnabled = Boolean(paymentConfig?.enabled && paymentConfig.clientId);
  const isQuoteConfirmation = confirmation?.status === "quote_requested";

  function updateField<K extends keyof ReservationForm>(key: K, value: ReservationForm[K]) {
    setForm((current) => ({ ...current, [key]: value }));
    if (checkoutBooking) setCheckoutBooking(null);
    if (error) setError("");
  }

  function adjustDuration(delta: number) {
    const currentDuration = isDurationValid ? durationHours : 1;
    updateField("durationHours", Math.min(24, Math.max(1, currentDuration + delta)));
  }

  function handlePaymentSuccess(result: PayPalPaymentSuccess) {
    setCheckoutBooking(null);
    setConfirmation({
      bookingId: result.bookingId,
      totalPrice: result.totalPrice,
      paymentStatus: result.paymentStatus,
      status: "confirmed",
      captureId: result.captureId,
    });
  }

  async function handlePayLater() {
    if (!checkoutBooking) return;

    setIsPayingLater(true);
    setError("");

    try {
      const response = await fetch(`/api/bookings/${checkoutBooking.bookingId}/pay-later`, {
        method: "POST",
      });
      const payload = (await response.json()) as {
        bookingId?: string;
        totalPrice?: number;
        paymentStatus?: string;
        message?: string;
      };

      if (!response.ok || !payload.bookingId || payload.totalPrice === undefined) {
        throw new Error(payload.message || "Impossible de confirmer la réservation sans paiement immédiat.");
      }

      setCheckoutBooking(null);
      setConfirmation({
        bookingId: payload.bookingId,
        totalPrice: payload.totalPrice,
        paymentStatus: payload.paymentStatus,
        status: "confirmed",
      });
    } catch (payLaterError) {
      setError(
        payLaterError instanceof Error
          ? payLaterError.message
          : "Impossible de confirmer la réservation sans paiement immédiat.",
      );
    } finally {
      setIsPayingLater(false);
    }
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (checkoutBooking) return;
    if (!isDisposition && distance === null) {
      setError("Indiquez une adresse de départ et de destination pour calculer votre trajet.");
      return;
    }
    if (isDisposition && !isDurationValid) {
      setError("Choisissez une durée estimée entre 1 et 24 heures.");
      return;
    }
    if (isDisposition && !isPassengerCountValid) {
      setError("Choisissez entre 1 et 4 passagers.");
      return;
    }
    if (isDisposition && !isQuoteDetailsValid) {
      setError("Décrivez brièvement votre programme pour permettre à N LEON de préparer votre devis.");
      return;
    }

    setIsSubmitting(true);
    setError("");

    try {
      const response = await fetch("/api/bookings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          paymentPreference: isDisposition ? "quote" : isPaymentEnabled ? "paypal" : "pay_later",
          durationHours: isDisposition ? durationHours : null,
          passengerCount: isDisposition ? passengerCount : null,
          estimatedDistance: isDisposition ? 0 : distance,
        }),
      });
      const payload = (await response.json()) as {
        bookingId?: string;
        totalPrice?: number;
        paymentStatus?: string;
        status?: string;
        message?: string;
      };

      if (!response.ok || !payload.bookingId || payload.totalPrice === undefined) {
        throw new Error(payload.message || "Votre réservation n’a pas pu être envoyée.");
      }

      if (isPaymentEnabled && payload.status === "pending_payment") {
        setCheckoutBooking({ bookingId: payload.bookingId, totalPrice: payload.totalPrice });
        window.setTimeout(() => {
          document.getElementById("paiement")?.scrollIntoView({ behavior: "smooth", block: "center" });
        }, 80);
        return;
      }

      setConfirmation({
        bookingId: payload.bookingId,
        totalPrice: payload.totalPrice,
        paymentStatus: payload.paymentStatus,
        status: payload.status,
      });
    } catch (submitError) {
      setError(
        submitError instanceof Error
          ? submitError.message
          : "Votre réservation n’a pas pu être envoyée.",
      );
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <main className="booking-app">
      {/* Halos dorés d'ambiance ultra-subtils */}
      <div className="ambient ambient-one" />
      <div className="ambient ambient-two" />
      <div className="ambient ambient-three" />

      {/* Barre supérieure Prestige */}
      <header className="topbar shell">
        <a className="wordmark" href="#accueil" aria-label="N LEON Chauffeur privé, accueil">
          <span className="wordmark-mark">N</span>
          <span className="wordmark-text">
            <strong>N LEON</strong>
            <small>Chauffeur Privé · Paris</small>
          </span>
        </a>

        <nav className={`main-nav ${mobileMenuOpen ? "open" : ""}`} aria-label="Navigation principale">
          <a href="#prestations" onClick={() => setMobileMenuOpen(false)}>Prestations</a>
          <a href="#vehicule" onClick={() => setMobileMenuOpen(false)}>Tesla Model Y</a>
          <a href="#engagements" onClick={() => setMobileMenuOpen(false)}>Engagements</a>
          <a href="#avis" onClick={() => setMobileMenuOpen(false)}>Avis</a>
          <a href="#faq" onClick={() => setMobileMenuOpen(false)}>FAQ</a>
          <a href="#reserver" className="nav-reserver-btn" onClick={() => setMobileMenuOpen(false)}>
            Réserver
          </a>
        </nav>

        <div className="header-actions">
          <a className="header-contact" href="tel:+33634507001" aria-label="Téléphone N LEON">
            <span className="contact-icon-pill">
              <Phone size={14} />
            </span>
            <div className="contact-text-wrap">
              <span className="contact-label">Ligne directe 24/7</span>
              <strong>06 34 50 70 01</strong>
            </div>
          </a>

          <a className="mobile-call-btn" href="tel:+33634507001" aria-label="Appeler N LEON au 06 34 50 70 01">
            <Phone size={17} />
          </a>

          <button
            className="menu-toggle-btn"
            type="button"
            aria-label="Ouvrir le menu de navigation"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </header>

      {/* ========================================================
          1. HERO SPECTACULAIRE — IMMERSION LUXE & CINÉMATIQUE
          ======================================================== */}
      <section id="accueil" className="hero-cinema">
        <div className="hero-cinema-backdrop">
          <img
            src="/images/tesla-model-y-black.jpg"
            alt="Tesla Model Y Noire Premium N LEON Chauffeur Privé"
            className="hero-cinema-img"
          />
          <div className="hero-cinema-gradient" />
          <div className="hero-cinema-noise" />
        </div>

        <div className="shell hero-cinema-content">
          <div className="hero-badge-wrap">
            <span className="hero-badge-pill">
              <Crown size={12} className="text-[#d7b577]" />
              <span>Service VTC d'Excellence · Cergy & Île-de-France</span>
            </span>
          </div>

          <h1 className="hero-cinema-title">
            Votre chauffeur privé.<br />
            <em>L'excellence à chaque trajet.</em>
          </h1>

          <p className="hero-cinema-subtitle">
            Chauffeur privé à Cergy et partout en Île-de-France.
          </p>

          <p className="hero-cinema-desc">
            Voyagez dans le silence absolu d'une <strong>Tesla Model Y Noire Premium</strong> avec intérieur cuir noir,
            jantes 19″ noires et vitres arrière surteintées. Une discrétion totale, une ponctualité rigoureuse.
          </p>

          <div className="hero-cinema-actions">
            <a className="btn-luxury btn-luxury-gold" href="#reserver">
              <span>Réserver mon chauffeur</span>
              <ArrowDownRight size={18} />
            </a>
            <a className="btn-luxury btn-luxury-outline" href="#reserver">
              <Sparkles size={16} />
              <span>Estimer mon trajet</span>
            </a>
          </div>

          {/* Barre de réassurance immédiate */}
          <div className="hero-trust-ribbon">
            <div className="trust-pill">
              <div className="trust-stars">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} size={13} fill="#d7b577" color="#d7b577" />
                ))}
              </div>
              <span><strong>4,9/5</strong> · +2 000 passagers conquis</span>
            </div>
            <div className="trust-divider" />
            <div className="trust-pill">
              <Check size={14} className="text-[#8fd4b4]" />
              <span>Annulation gratuite jusqu’à 1h avant</span>
            </div>
            <div className="trust-divider" />
            <div className="trust-pill">
              <ShieldCheck size={14} className="text-[#d7b577]" />
              <span>Prix fixe garanti, sans surprise</span>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================
          4. FORMULAIRE DE RÉSERVATION HAUT DE GAMME (Immédiatement après le Hero)
          ======================================================== */}
      <section id="reserver" className="section-luxury shell section-reserver-focus">
        <div className="booking-layout-wrap">
          {/* Côté gauche : Texte & réassurance */}
          <div className="booking-intro-pane">
            <p className="eyebrow-gold"><span /> Réservation Immédiate</p>
            <h2 className="title-serif">
              Réservez votre trajet<br />
              <em>en quelques secondes.</em>
            </h2>
            <p className="booking-intro-text">
              Bénéficiez d'une estimation tarifaire en temps réel, d'un prix garanti sans majoration imprévue
              et de l'assurance d'un chauffeur professionnel qui se tient à votre entière disposition.
            </p>

            <div className="booking-highlights-list">
              <div className="highlight-row">
                <span className="hl-icon"><Check size={16} /></span>
                <div>
                  <strong>Annulation sans frais</strong>
                  <p>Modifiez ou annulez gratuitement jusqu'à 1 heure avant l'horaire de prise en charge.</p>
                </div>
              </div>
              <div className="highlight-row">
                <span className="hl-icon"><ShieldCheck size={16} /></span>
                <div>
                  <strong>Prix fixe & transparent</strong>
                  <p>Forfait de base 10 € + 2,00 €/km calculé précisément, sans frais cachés ni mauvaise surprise.</p>
                </div>
              </div>
              <div className="highlight-row">
                <span className="hl-icon"><Clock3 size={16} /></span>
                <div>
                  <strong>Ponctualité rigoureuse</strong>
                  <p>Votre chauffeur arrive en avance pour vous accueillir dans les meilleures conditions.</p>
                </div>
              </div>
            </div>

            {/* Assistance directe en cas d'urgence */}
            <div className="need-help-card">
              <div className="help-icon"><Phone size={20} /></div>
              <div>
                <span>Une question ou un départ immédiat ?</span>
                <strong>Appelez N LEON : 06 34 50 70 01</strong>
              </div>
            </div>
          </div>

          {/* Côté droit : Formulaire Ultra-Premium */}
          <form className="booking-card-lux" id="booking-form-element" onSubmit={handleSubmit}>
            <div className="booking-card-top">
              <div>
                <span className="step-tag">01 — Prestation</span>
                <h3 className="card-heading-title">
                  {isDisposition ? "Demande de Mise à Disposition" : "Où allons-nous aujourd'hui ?"}
                </h3>
              </div>
              <div className="secure-badge-gold">
                <ShieldCheck size={14} />
                <span>{isDisposition ? "Devis sans engagement" : "Paiement 100% sécurisé"}</span>
              </div>
            </div>

            {/* Sélecteur de type de service */}
            <div className="service-tabs-lux" role="group" aria-label="Choisir le type de prestation">
              <button
                type="button"
                className={`tab-btn-lux ${!isDisposition ? "active" : ""}`}
                aria-pressed={!isDisposition}
                onClick={() => updateField("serviceType", "course")}
              >
                <span className="tab-title">Course / Transfert</span>
                <span className="tab-price-hint">10 € + 2,00 €/km</span>
              </button>
              <button
                type="button"
                className={`tab-btn-lux ${isDisposition ? "active" : ""}`}
                aria-pressed={isDisposition}
                onClick={() => updateField("serviceType", "disposition")}
              >
                <span className="tab-title">Mise à disposition</span>
                <span className="tab-price-hint">Devis personnalisé</span>
              </button>
            </div>

            {/* Étape Itinéraire */}
            <div className="form-sub-header">
              <span>02 — {isDisposition ? "Lieu & Détails du besoin" : "Itinéraire du trajet"}</span>
              <small>{isDisposition ? "Point de départ & programme" : "Prise en charge & destination"}</small>
            </div>

            <div className="route-fields-lux">
              <label className="field-lux">
                <span className="field-label">
                  <LocateFixed size={14} className="text-[#d7b577]" />
                  <span>{isDisposition ? "Point de prise en charge" : "Adresse de prise en charge (Départ)"}</span>
                </span>
                <input
                  required
                  value={form.pickupAddress}
                  onChange={(e) => updateField("pickupAddress", e.target.value)}
                  placeholder="Ex : 10 rue Gioachino Rossini, Saint-Ouen-l’Aumône"
                  autoComplete="street-address"
                />
              </label>

              {!isDisposition && (
                <label className="field-lux">
                  <span className="field-label">
                    <MapPin size={14} className="text-[#d7b577]" />
                    <span>Adresse de destination (Arrivée)</span>
                  </span>
                  <input
                    required
                    value={form.dropoffAddress}
                    onChange={(e) => updateField("dropoffAddress", e.target.value)}
                    placeholder="Ex : Aéroport Paris Roissy CDG, Terminal 2"
                    autoComplete="off"
                  />
                </label>
              )}
            </div>

            {/* Date et Heure */}
            <div className="datetime-row-lux">
              <label className="field-lux">
                <span className="field-label">
                  <CalendarDays size={14} className="text-[#d7b577]" />
                  <span>Date</span>
                </span>
                <input
                  required
                  min={today}
                  type="date"
                  value={form.pickupDate}
                  onChange={(e) => updateField("pickupDate", e.target.value)}
                />
              </label>
              <label className="field-lux">
                <span className="field-label">
                  <Clock3 size={14} className="text-[#d7b577]" />
                  <span>Heure de prise en charge</span>
                </span>
                <input
                  required
                  type="time"
                  value={form.pickupTime}
                  onChange={(e) => updateField("pickupTime", e.target.value)}
                />
              </label>
            </div>

            {/* Champs spécifiques mise à disposition */}
            {isDisposition && (
              <div className="dispo-fields-lux">
                <div className="dispo-duration-box">
                  <div className="duration-head">
                    <div>
                      <span className="sub-label">Durée estimée souhaitée</span>
                      <strong className="duration-value">
                        {isDurationValid ? `${durationHours} heure${durationHours > 1 ? "s" : ""}` : "À définir"}
                      </strong>
                    </div>
                    <span className="quote-pill">Devis sur mesure</span>
                  </div>

                  <div className="duration-stepper-lux">
                    <button
                      type="button"
                      onClick={() => adjustDuration(-1)}
                      disabled={isDurationValid && durationHours <= 1}
                      aria-label="Réduire la durée"
                    >
                      <Minus size={15} />
                    </button>
                    <span className="stepper-display">{durationHours} h</span>
                    <button
                      type="button"
                      onClick={() => adjustDuration(1)}
                      disabled={isDurationValid && durationHours >= 24}
                      aria-label="Augmenter la durée"
                    >
                      <Plus size={15} />
                    </button>
                  </div>

                  <div className="presets-lux">
                    {[2, 4, 8, 12].map((hours) => (
                      <button
                        key={hours}
                        type="button"
                        className={`preset-chip ${durationHours === hours ? "selected" : ""}`}
                        onClick={() => updateField("durationHours", hours)}
                      >
                        {hours} h
                      </button>
                    ))}
                  </div>
                </div>

                <div className="passengers-box-lux">
                  <label className="field-lux">
                    <span className="field-label">
                      <Users size={14} className="text-[#d7b577]" />
                      <span>Nombre de passagers</span>
                    </span>
                    <select
                      value={passengerCount}
                      onChange={(e) => updateField("passengerCount", Number(e.target.value))}
                      aria-label="Nombre de passagers"
                    >
                      {[1, 2, 3, 4].map((count) => (
                        <option key={count} value={count}>
                          {count} passager{count > 1 ? "s" : ""} (Berline Tesla)
                        </option>
                      ))}
                    </select>
                  </label>

                  <label className="field-lux">
                    <span className="field-label">
                      <span>Programme & étapes prévues</span>
                    </span>
                    <textarea
                      required
                      minLength={10}
                      maxLength={1000}
                      rows={3}
                      value={form.quoteDetails}
                      onChange={(e) => updateField("quoteDetails", e.target.value)}
                      placeholder="Précisez votre programme (ex : Mariage à Cergy, photos à Paris, plusieurs arrêts…) pour que N LEON étudie votre tarif personnalisé."
                    />
                  </label>
                </div>
              </div>
            )}

            {/* Étape Véhicule */}
            <div className="form-sub-header">
              <span>03 — Véhicule d'exception</span>
              <small>Confort garanti à bord</small>
            </div>

            <div className="vehicle-card-lux">
              <div className="vehicle-preview-lux">
                <img
                  src="/images/tesla-model-y-black.jpg"
                  alt="Tesla Model Y Noire Premium avec jantes noires 19 pouces"
                  className="vehicle-thumb-img"
                  loading="lazy"
                />
              </div>
              <div className="vehicle-details-lux">
                <div className="vehicle-badge-line">
                  <strong>Tesla Model Y · Noire Premium</strong>
                  <span className="v-tag-official"><Check size={12} /> Véhicule Officiel N LEON</span>
                </div>
                <p className="vehicle-desc-mini">
                  Noir métallisé · Cuir noir intégral · Jantes sport 19″ · Vitres arrière surteintées (intimité)
                </p>
                <div className="vehicle-chips-row">
                  <span>1 à 4 passagers</span>
                  <span>100% électrique silencieux</span>
                  <span>Toit panoramique</span>
                  <span>Climatisation bizone</span>
                </div>
              </div>
            </div>

            {/* Bloc Estimation Tarifaire */}
            <div className={`estimate-lux ${hasEstimate ? "ready" : ""}`}>
              <div className="est-col">
                <span className="est-label">{isDisposition ? "Durée estimée" : "Distance estimée"}</span>
                <strong className="est-metric">
                  {isDisposition
                    ? isDurationValid
                      ? `${durationHours} heure${durationHours > 1 ? "s" : ""}`
                      : "—"
                    : distance === null
                      ? "—"
                      : `${distance.toLocaleString("fr-FR")} km`}
                </strong>
              </div>

              <div className="est-col est-col-price">
                <span className="est-label">{isDisposition ? "Tarif prestation" : "Votre tarif garanti"}</span>
                <strong className="est-amount">
                  {isDisposition ? "Sur Devis" : hasEstimate ? money.format(total) : "—"}
                </strong>
              </div>

              <div className="est-formula-line">
                <Info size={13} className="text-[#d7b577]" />
                <span>
                  {isDisposition
                    ? hasEstimate
                      ? "Demande de devis sans engagement : N LEON vous contactera rapidement pour convenir du prix."
                      : "Renseignez les détails de votre programme pour soumettre votre demande."
                    : distance === null
                      ? "Indiquez les adresses de départ et de destination pour calculer votre prix en temps réel."
                      : "Tarif transparent : Forfait de base 10 € + 2,00 € par kilomètre parcouru."}
                </span>
              </div>
            </div>

            {/* Conditions d'annulation */}
            <div className="cancellation-ribbon-lux">
              <Check size={15} className="text-[#8fd4b4]" />
              <span>
                <strong>Annulation sans frais</strong> jusqu’à 1h avant la prise en charge.
              </span>
            </div>

            {/* Étape 04 : Informations Voyageur */}
            <div className="form-sub-header">
              <span>04 — Vos coordonnées</span>
              <small>Pour vous accueillir et confirmer votre trajet</small>
            </div>

            <div className="client-inputs-grid">
              <label className="field-lux full-span">
                <span className="field-label">Nom et prénom complet</span>
                <input
                  required
                  value={form.customerName}
                  onChange={(e) => updateField("customerName", e.target.value)}
                  placeholder="Ex : Jean Dupont"
                  autoComplete="name"
                />
              </label>
              <label className="field-lux">
                <span className="field-label">Numéro de téléphone</span>
                <input
                  required
                  type="tel"
                  value={form.customerPhone}
                  onChange={(e) => updateField("customerPhone", e.target.value)}
                  placeholder="06 00 00 00 00"
                  autoComplete="tel"
                />
              </label>
              <label className="field-lux">
                <span className="field-label">Adresse email</span>
                <input
                  required
                  type="email"
                  value={form.customerEmail}
                  onChange={(e) => updateField("customerEmail", e.target.value)}
                  placeholder="votre.email@domaine.com"
                  autoComplete="email"
                />
              </label>
            </div>

            {/* Étape 05 : Mode de Paiement / Règlement */}
            {isDisposition ? (
              <div className="quote-call-section" id="devis">
                <div className="form-sub-header">
                  <span>05 — Fixer le prix</span>
                  <small>Formulaire direct ou échange téléphonique</small>
                </div>
                <div className="quote-action-card">
                  <div className="quote-action-text">
                    <strong>Tarif sur mesure fixé avec N LEON</strong>
                    <p>Envoyez votre demande ci-dessous ou appelez immédiatement pour convenir du tarif.</p>
                  </div>
                  <a className="quote-phone-btn" href="tel:+33634507001">
                    <Phone size={16} /> 06 34 50 70 01
                  </a>
                </div>
              </div>
            ) : (
              <div className="payment-options-box" id="paiement">
                <div className="form-sub-header">
                  <span>05 — Paiement sécurisé</span>
                  <small>En ligne (PayPal / Carte Bancaire) ou plus tard à bord</small>
                </div>

                <div className="payment-status-pill-card">
                  <CreditCard size={20} className="text-[#d7b577]" />
                  <div className="payment-status-info">
                    <strong>{checkoutBooking ? money.format(checkoutBooking.totalPrice) : hasEstimate ? money.format(total) : "Montant calculé"}</strong>
                    <small>
                      {checkoutBooking
                        ? "Réservation enregistrée — Paiement en attente"
                        : isPaymentEnabled
                          ? "Paiement sécurisé par PayPal ou Carte Bancaire"
                          : "Paiement à bord ou plus tard accepté"}
                    </small>
                  </div>
                  <span className="ssl-shield"><ShieldCheck size={13} /> Chiffrement SSL</span>
                </div>

                {checkoutBooking && paymentConfig?.clientId ? (
                  <div className="paypal-live-area">
                    <PayPalCheckout
                      bookingId={checkoutBooking.bookingId}
                      clientId={paymentConfig.clientId}
                      environment={paymentConfig.environment}
                      onSuccess={handlePaymentSuccess}
                    />
                    <button
                      className="btn-pay-later-lux"
                      type="button"
                      onClick={handlePayLater}
                      disabled={isPayingLater}
                    >
                      {isPayingLater ? (
                        <><LoaderCircle className="spin" size={16} /> Confirmation en cours…</>
                      ) : (
                        <>Confirmer et régler le chauffeur plus tard</>
                      )}
                    </button>
                  </div>
                ) : (
                  <div className="payment-guarantee-note">
                    <Check size={14} className="text-[#8fd4b4]" />
                    <span>Vous pourrez payer en ligne par PayPal / Carte ou directement à bord auprès du chauffeur.</span>
                  </div>
                )}
              </div>
            )}

            {error && <p className="form-error-lux" role="alert">{error}</p>}

            {!checkoutBooking && (
              <button className="btn-submit-luxury" type="submit" disabled={isSubmitting}>
                {isSubmitting ? (
                  <><LoaderCircle className="spin" size={19} /> {isDisposition ? "Envoi de votre demande…" : isPaymentEnabled ? "Préparation du paiement…" : "Confirmation en cours…"}</>
                ) : isDisposition ? (
                  <>Envoyer ma demande de devis <Send size={18} /></>
                ) : isPaymentEnabled ? (
                  <>Continuer vers le paiement sécurisé <ArrowRight size={19} /></>
                ) : (
                  <>Confirmer la réservation <ArrowRight size={19} /></>
                )}
              </button>
            )}

            <p className="privacy-reassurance">
              <ShieldCheck size={14} className="text-[#8fd4b4]" />
              <span>Vos informations personnelles sont strictement confidentielles et protégées.</span>
            </p>
          </form>
        </div>
      </section>

      {/* ========================================================
          2. PRESTATIONS D'EXCEPTION & USAGES SUR MESURE
          ======================================================== */}
      <section id="prestations" className="section-luxury shell">
        <div className="section-head-center">
          <p className="eyebrow-gold">
            <span /> L’Excellence N LEON <span />
          </p>
          <h2 className="title-serif">
            Des prestations pensées<br />
            <em>pour les plus exigeants.</em>
          </h2>
          <p className="section-lead">
            Que vous voyagiez pour affaires ou pour le plaisir, chaque course est orchestrée pour vous apporter
            sérénité, ponctualité et confort d'exception.
          </p>
        </div>

        <div className="services-grid-luxury">
          {/* Service 1 : Aéroports */}
          <article className="service-card-lux">
            <div className="service-card-media">
              <img
                src="/images/paris-airport-transfer.jpg"
                alt="Transfert aéroport Roissy CDG Orly Chauffeur Privé"
                className="service-media-img"
                loading="lazy"
              />
              <span className="service-tag">Liaison Express VIP</span>
            </div>
            <div className="service-card-body">
              <div className="service-icon-seal">
                <Plane size={22} />
              </div>
              <h3 className="service-title">Transferts Aéroports</h3>
              <p className="service-desc">
                Roissy CDG, Orly, Beauvais, Le Bourget. Suivi de vol en direct, ajustement automatique en cas de retard,
                accueil en hall avec pancarte nominative et port des bagages.
              </p>
              <ul className="service-perks">
                <li><Check size={14} /> Suivi de vol en direct inclus</li>
                <li><Check size={14} /> 20 min d'attente offerte à l'arrivée</li>
                <li><Check size={14} /> Dépose express au terminal dédié</li>
              </ul>
              <a
                href="#reserver"
                className="service-action-link"
                onClick={() => updateField("serviceType", "course")}
              >
                <span>Réserver un transfert aéroport</span>
                <ChevronRight size={16} />
              </a>
            </div>
          </article>

          {/* Service 2 : Gares & Paris Centre */}
          <article className="service-card-lux">
            <div className="service-card-media">
              <img
                src="/images/tesla-model-y-black.jpg"
                alt="Transferts gares parisiennes et Paris centre"
                className="service-media-img"
                loading="lazy"
              />
              <span className="service-tag">Ponctualité Absolue</span>
            </div>
            <div className="service-card-body">
              <div className="service-icon-seal">
                <Train size={22} />
              </div>
              <h3 className="service-title">Gares & Paris Centre</h3>
              <p className="service-desc">
                Gare du Nord, Gare de Lyon, Montparnasse, Saint-Lazare. Évitez les files de taxis et le stress
                du trafic : votre chauffeur vous attend à l'heure exacte convenue.
              </p>
              <ul className="service-perks">
                <li><Check size={14} /> Accès couloirs réservés & dépose fluide</li>
                <li><Check size={14} /> Prise en charge au plus près du quai</li>
                <li><Check size={14} /> Connexion directe Cergy ↔ Paris</li>
              </ul>
              <a
                href="#reserver"
                className="service-action-link"
                onClick={() => updateField("serviceType", "course")}
              >
                <span>Planifier un trajet gare</span>
                <ChevronRight size={16} />
              </a>
            </div>
          </article>

          {/* Service 3 : Déplacements Business */}
          <article className="service-card-lux">
            <div className="service-card-media">
              <img
                src="/images/tesla-model-y-interior.jpg"
                alt="Déplacements professionnels VIP et business"
                className="service-media-img"
                loading="lazy"
              />
              <span className="service-tag">Discrétion & Silence</span>
            </div>
            <div className="service-card-body">
              <div className="service-icon-seal">
                <Briefcase size={22} />
              </div>
              <h3 className="service-title">Affaires & Déplacements Pro</h3>
              <p className="service-desc">
                Dirigeants, cadres et délégations. Transformez votre trajet en espace de travail mobile :
                silence absolu, vitres teintées à l'abri des regards, chargeurs rapides à bord et factures pro avec TVA.
              </p>
              <ul className="service-perks">
                <li><Check size={14} /> Confidentialité totale garantie</li>
                <li><Check size={14} /> Chargeurs multi-ports & rafraîchissements</li>
                <li><Check size={14} /> Facture pro détaillée envoyée par email</li>
              </ul>
              <a
                href="#reserver"
                className="service-action-link"
                onClick={() => updateField("serviceType", "course")}
              >
                <span>Organiser un trajet business</span>
                <ChevronRight size={16} />
              </a>
            </div>
          </article>

          {/* Service 4 : Mise à disposition sur mesure */}
          <article className="service-card-lux highlight-card">
            <div className="service-card-media">
              <img
                src="/images/tesla-model-y-black.jpg"
                alt="Mise à disposition avec chauffeur privé dédié"
                className="service-media-img"
                loading="lazy"
              />
              <span className="service-tag highlight-tag">Sur Devis Direct</span>
            </div>
            <div className="service-card-body">
              <div className="service-icon-seal">
                <Clock3 size={22} />
              </div>
              <h3 className="service-title">Mise à Disposition Sur Mesure</h3>
              <p className="service-desc">
                Un véhicule d'exception et son chauffeur privé entièrement dédiés à votre emploi du temps :
                demi-journée, journée entière, mariages, soirées privées, shopping parisien ou événements d'entreprise.
              </p>
              <ul className="service-perks">
                <li><Check size={14} /> Chauffeur dédié en attente permanente</li>
                <li><Check size={14} /> Nombre d'arrêts et étapes illimité</li>
                <li><Check size={14} /> Tarif fixé ensemble en direct ou par téléphone</li>
              </ul>
              <div className="service-action-dual">
                <a
                  href="#reserver"
                  className="btn-lux-small"
                  onClick={() => updateField("serviceType", "disposition")}
                >
                  Demander un devis
                </a>
                <a href="tel:+33634507001" className="btn-lux-call-small">
                  <Phone size={13} /> 06 34 50 70 01
                </a>
              </div>
            </div>
          </article>
        </div>
      </section>

      {/* ========================================================
          3. PRÉSENTATION IMMERSIVE DU VÉHICULE : TESLA MODEL Y
          ======================================================== */}
      <section id="vehicule" className="section-luxury shell" aria-label="Présentation détaillée de la Tesla Model Y">
        <div className="section-head-split">
          <div>
            <p className="eyebrow-gold"><span /> Votre Berline Officielle</p>
            <h2 className="title-serif">
              Tesla Model Y<br />
              <em>Noire Premium</em>
            </h2>
          </div>
          <p className="split-desc">
            Pour vos trajets à Cergy et en Île-de-France, N LEON a sélectionné l’une des berlines les plus luxueuses,
            écologiques et confortables au monde : carrosserie noir métallisé profond, jantes sport noires 19 pouces et
            vitres arrière surteintées pour une intimité préservée.
          </p>
        </div>

        <div className="tesla-gallery-grid">
          {/* Photo 1 : Extérieur */}
          <div className="tesla-display-card">
            <div className="tesla-img-frame">
              <img
                src="/images/tesla-model-y-black.jpg"
                alt="Tesla Model Y Noire Premium avec jantes 19 pouces noires"
                className="tesla-img-zoom"
                loading="lazy"
              />
              <span className="tesla-badge-floating">Extérieur Noir Métallisé · Jantes 19″</span>
            </div>
            <div className="tesla-desc-box">
              <div className="desc-header">
                <strong>Ligne racée & Prestance prestigieuse</strong>
                <span className="spec-tag">Noir Absolu</span>
              </div>
              <p>
                Une silhouette aérodynamique sculpturale, associée à des jantes noires sport de 19 pouces et des
                vitres arrière surteintées d'origine pour vous déplacer en toute discrétion à l'abri des regards.
              </p>
            </div>
          </div>

          {/* Photo 2 : Intérieur */}
          <div className="tesla-display-card">
            <div className="tesla-img-frame">
              <img
                src="/images/tesla-model-y-interior.jpg"
                alt="Intérieur cuir noir premium et toit panoramique Tesla Model Y"
                className="tesla-img-zoom"
                loading="lazy"
              />
              <span className="tesla-badge-floating">Intérieur Cuir Noir Premium · Toit Verre</span>
            </div>
            <div className="tesla-desc-box">
              <div className="desc-header">
                <strong>Habitacle épuré & Confort de première classe</strong>
                <span className="spec-tag">Cuir Noir</span>
              </div>
              <p>
                Sellerie cuir noir ergonomique, toit panoramique en verre baignant l'espace de lumière tamisée,
                climatisation bizone silencieuse, bouteilles d'eau fraîches et chargeurs rapides pour vos appareils.
              </p>
            </div>
          </div>
        </div>

        {/* 5 Piliers Véhicule */}
        <div className="car-pillars-grid">
          <div className="pillar-item">
            <div className="pillar-num">1 à 4</div>
            <div className="pillar-title">Passagers Confort</div>
            <p className="pillar-sub">Espace royal pour les jambes & bagages</p>
          </div>
          <div className="pillar-item">
            <div className="pillar-num">19″</div>
            <div className="pillar-title">Jantes Sport Noires</div>
            <p className="pillar-sub">Design raffiné & tenue de route souveraine</p>
          </div>
          <div className="pillar-item">
            <div className="pillar-num">Noir</div>
            <div className="pillar-title">Cuir Intégral Premium</div>
            <p className="pillar-sub">Finition noble, douce et respirante</p>
          </div>
          <div className="pillar-item">
            <div className="pillar-num">100%</div>
            <div className="pillar-title">Vitres AR Surteintées</div>
            <p className="pillar-sub">Intimité absolue & protection thermique</p>
          </div>
          <div className="pillar-item">
            <div className="pillar-num">0 dB</div>
            <div className="pillar-title">Silence Électrique</div>
            <p className="pillar-sub">Aucune vibration, sérénité totale</p>
          </div>
        </div>
      </section>



      {/* ========================================================
          5. ENGAGEMENTS D'EXCELLENCE & QUALITÉ
          ======================================================== */}
      <section id="engagements" className="section-luxury shell">
        <div className="section-head-center">
          <p className="eyebrow-gold"><span /> Nos Valeurs Fondamentales <span />
          </p>
          <h2 className="title-serif">
            Les exigences de la haute conciergerie,<br />
            <em>appliquées à chacun de vos trajets.</em>
          </h2>
        </div>

        <div className="commitments-luxury-grid">
          <div className="commit-box">
            <span className="commit-num">01</span>
            <div className="commit-icon-circle"><Clock3 size={24} /></div>
            <h3>Ponctualité Rigoureuse</h3>
            <p>
              Votre chauffeur se présente systématiquement avec 10 à 15 minutes d’avance sur l’horaire convenu.
              Aucun stress, aucune attente : votre temps est précieux.
            </p>
          </div>

          <div className="commit-box">
            <span className="commit-num">02</span>
            <div className="commit-icon-circle"><Car size={24} /></div>
            <h3>Véhicule Impeccable</h3>
            <p>
              La Tesla Model Y est minutieusement nettoyée et désinfectée entre chaque client.
              Bouteilles d'eau, chargeurs smartphones et climatisation sur mesure à bord.
            </p>
          </div>

          <div className="commit-box">
            <span className="commit-num">03</span>
            <div className="commit-icon-circle"><ShieldCheck size={24} /></div>
            <h3>Discrétion & Sérénité</h3>
            <p>
              Chauffeur professionnel en tenue formelle soignée, respect strict de la confidentialité
              de vos échanges et conduite souple et apaisante.
            </p>
          </div>

          <div className="commit-box">
            <span className="commit-num">04</span>
            <div className="commit-icon-circle"><Check size={24} /></div>
            <h3>Flexibilité Sans Frais</h3>
            <p>
              Un imprévu ? Annulez ou modifiez votre réservation sans aucun frais jusqu'à 1 heure avant
              la prise en charge. Assistance 24h/24 et 7j/7 disponible.
            </p>
          </div>
        </div>
      </section>

      {/* ========================================================
          6. AVIS CLIENTS AUTHENTIQUES (Preuve sociale)
          ======================================================== */}
      <section id="avis" className="section-luxury shell">
        <div className="section-head-center">
          <p className="eyebrow-gold"><span /> Témoignages de Prestige <span />
          </p>
          <h2 className="title-serif">
            La satisfaction de nos passagers,<br />
            <em>notre plus belle signature.</em>
          </h2>
          <p className="section-lead">
            Découvrez les retours d'expérience de nos clients fidèles qui nous accordent leur confiance
            pour leurs trajets d'affaires et transferts privés.
          </p>
        </div>

        <div className="reviews-luxury-grid">
          {REVIEWS.map((review, idx) => (
            <article key={idx} className="review-card-lux">
              <div className="review-header">
                <div className="review-stars">
                  {[...Array(review.rating)].map((_, i) => (
                    <Star key={i} size={15} fill="#d7b577" color="#d7b577" />
                  ))}
                </div>
                <span className="review-date">{review.date}</span>
              </div>
              <p className="review-text">« {review.text} »</p>
              <div className="review-author">
                <div className="author-avatar">{review.name.charAt(0)}</div>
                <div>
                  <strong>{review.name}</strong>
                  <small>{review.role} · {review.city}</small>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* ========================================================
          7. QUESTIONS FRÉQUENTES (FAQ Accordéon interactif)
          ======================================================== */}
      <section id="faq" className="section-luxury shell">
        <div className="section-head-center">
          <p className="eyebrow-gold"><span /> Vos Questions, Nos Réponses <span />
          </p>
          <h2 className="title-serif">
            Foire aux questions<br />
            <em>pour préparer votre trajet.</em>
          </h2>
        </div>

        <div className="faq-accordion-wrap">
          {FAQ_ITEMS.map((item, idx) => {
            const isOpen = openFaqIndex === idx;
            return (
              <div key={idx} className={`faq-item-lux ${isOpen ? "open" : ""}`}>
                <button
                  type="button"
                  className="faq-question-btn"
                  onClick={() => setOpenFaqIndex(isOpen ? null : idx)}
                  aria-expanded={isOpen}
                >
                  <span className="faq-q-text">
                    <HelpCircle size={18} className="text-[#d7b577] flex-shrink-0" />
                    <span>{item.question}</span>
                  </span>
                  <ChevronDown
                    size={18}
                    className={`faq-chevron ${isOpen ? "rotate-180" : ""}`}
                  />
                </button>
                {isOpen && (
                  <div className="faq-answer-body">
                    <p>{item.answer}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* ========================================================
          8. BANNIÈRE D'APPEL À L'ACTION (CTA FINAL PRESTIGE)
          ======================================================== */}
      <section className="cta-banner-section shell">
        <div className="cta-banner-card">
          <div className="cta-banner-content">
            <span className="cta-tag">Disponibilité Immédiate & Réservation 24/7</span>
            <h2 className="cta-title">
              Prêt à vivre une expérience de transport<br />
              <em>véritablement haut de gamme ?</em>
            </h2>
            <p className="cta-desc">
              Réservez en ligne en quelques clics ou contactez directement votre chauffeur au <strong>06 34 50 70 01</strong>.
            </p>
            <div className="cta-actions">
              <a href="#reserver" className="btn-luxury btn-luxury-gold">
                <span>Réserver maintenant</span>
                <ArrowRight size={18} />
              </a>
              <a href="tel:+33634507001" className="btn-luxury btn-luxury-outline">
                <Phone size={16} />
                <span>06 34 50 70 01</span>
              </a>
              <a
                href="https://wa.me/33634507001?text=Bonjour%20N%20LEON,%20je%20souhaite%20r%C3%A9server%20un%20trajet"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-luxury btn-luxury-wa"
              >
                <WhatsAppIcon width={17} height={17} />
                <span>WhatsApp Direct</span>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================
          9. PIED DE PAGE HAUTE COUTURE (Footer)
          ======================================================== */}
      <footer className="footer-lux shell">
        <div className="footer-grid-top">
          {/* Col 1 : Marque & Présentation */}
          <div className="footer-brand-pane">
            <a className="wordmark" href="#accueil">
              <span className="wordmark-mark">N</span>
              <span className="wordmark-text">
                <strong>N LEON</strong>
                <small>Chauffeur Privé · Paris & Île-de-France</small>
              </span>
            </a>
            <p className="footer-brand-desc">
              Service VTC haut de gamme à Cergy, Saint-Ouen-l’Aumône et dans toute la région parisienne.
              Transport d'exception exclusivement en Berline Tesla Model Y Noire Premium.
            </p>
            <div className="footer-badges">
              <span>Berline 100% Électrique</span>
              <span>Agrément VTC Officiel</span>
            </div>
          </div>

          {/* Col 2 : Navigation rapide */}
          <div className="footer-nav-col">
            <h4 className="footer-col-title">Navigation</h4>
            <ul className="footer-links">
              <li><a href="#accueil">Accueil</a></li>
              <li><a href="#prestations">Prestations Aéroports & Gares</a></li>
              <li><a href="#vehicule">Tesla Model Y Noire</a></li>
              <li><a href="#reserver">Calculateur & Réservation</a></li>
              <li><a href="#engagements">Nos Engagements</a></li>
              <li><a href="#avis">Avis Clients</a></li>
              <li><a href="#faq">Questions Fréquentes</a></li>
            </ul>
          </div>

          {/* Col 3 : Contact & Horaires */}
          <div className="footer-contact-col">
            <h4 className="footer-col-title">Ligne Directe 24/7</h4>
            <div className="footer-contact-items">
              <a className="f-contact-line phone-line" href="tel:+33634507001">
                <Phone size={15} />
                <span>06 34 50 70 01</span>
              </a>
              <a className="f-contact-line email-line" href="mailto:nleonfm@gmail.com">
                <Mail size={15} />
                <span>nleonfm@gmail.com</span>
              </a>
              <div className="f-contact-line address-line">
                <MapPin size={15} />
                <span>10 rue Gioachino Rossini, Saint-Ouen-l’Aumône, France</span>
              </div>
            </div>
            <p className="footer-avail-note">
              <span className="live-dot" /> Service disponible 24 heures sur 24, 7 jours sur 7.
            </p>
          </div>

          {/* Col 4 : Réseaux sociaux & messageries */}
          <div className="footer-social-col">
            <h4 className="footer-col-title">Messageries & Réseaux</h4>
            <p className="social-sub">Échangez en direct avec votre chauffeur sur votre application préférée :</p>
            <div className="footer-social-buttons">
              <a
                href="https://wa.me/33634507001?text=Bonjour%20N%20LEON,%20je%20souhaite%20r%C3%A9server%20un%20trajet"
                target="_blank"
                rel="noopener noreferrer"
                className="f-soc-btn f-soc-wa"
                title="WhatsApp N LEON"
              >
                <WhatsAppIcon width={16} height={16} />
                <span>WhatsApp</span>
              </a>
              <a
                href="https://t.me/+33634507001"
                target="_blank"
                rel="noopener noreferrer"
                className="f-soc-btn f-soc-tg"
                title="Telegram N LEON"
              >
                <TelegramIcon width={16} height={16} />
                <span>Telegram</span>
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="f-soc-btn f-soc-ig"
                title="Instagram N LEON"
              >
                <InstagramIcon width={16} height={16} />
                <span>Instagram</span>
              </a>
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="f-soc-btn f-soc-fb"
                title="Facebook N LEON"
              >
                <FacebookIcon width={16} height={16} />
                <span>Facebook</span>
              </a>
            </div>
          </div>
        </div>

        {/* Ligne légale inférieure */}
        <div className="footer-legal-bar">
          <p>© {new Date().getFullYear()} N LEON. Tous droits réservés.</p>
          <div className="legal-notes">
            <span>SIRET : 812 053 320 00030</span>
            <span className="dot-sep">·</span>
            <span>N° de registre VTC à compléter</span>
            <span className="dot-sep">·</span>
            <span>Saint-Ouen-l’Aumône & Cergy, France</span>
          </div>
        </div>
      </footer>

      {/* ========================================================
          BOUTONS FLOTTANTS MOBILES & TCHAT DIRECT
          ======================================================== */}
      {/* Bouton de réservation flottant rapide */}
      <a
        className="floating-booking-btn"
        href="#reserver"
        aria-label="Accéder au formulaire de réservation"
      >
        <CalendarDays size={18} strokeWidth={2.2} />
        <span>Réserver mon chauffeur</span>
      </a>

      {/* Bouton d'appel flottant */}
      <a className="floating-call" href="tel:+33634507001" aria-label="Appeler N LEON au 06 34 50 70 01">
        <Phone size={16} /> <span>06 34 50 70 01</span>
      </a>

      {/* Espace de Tchat en Direct N LEON */}
      <LiveChat />

      {/* ========================================================
          MODALE DE CONFIRMATION DE RÉSERVATION / DEVIS
          ======================================================== */}
      {confirmation && (
        <div className="modal-backdrop" role="presentation">
          <section className="confirmation-modal" role="dialog" aria-modal="true" aria-labelledby="confirmation-title">
            <button
              className="modal-close"
              onClick={() => setConfirmation(null)}
              type="button"
              aria-label="Fermer le récapitulatif"
            >
              <X size={20} />
            </button>
            <div className="confirmation-seal">
              <Check size={31} strokeWidth={2.1} />
            </div>
            <p className="eyebrow centered">
              <span /> {isQuoteConfirmation ? "Demande de devis transmise" : "Réservation confirmée"}
            </p>
            <h2 id="confirmation-title">
              Merci, {form.customerName.split(" ")[0] || "à vous"}&nbsp;!
            </h2>
            <p className="modal-intro">
              {isQuoteConfirmation
                ? "Votre demande de mise à disposition a bien été transmise à N LEON. Votre chauffeur vous contactera très rapidement pour étudier votre itinéraire et fixer le tarif avec vous."
                : "Votre réservation a été validée avec succès. Un chauffeur N LEON se tient prêt pour votre prise en charge dans les meilleures conditions."}
            </p>
            <div className="modal-summary">
              <div>
                <span>Prestation</span>
                <strong>{isDisposition ? "Mise à disposition avec chauffeur" : "Course / Transfert privé"}</strong>
              </div>
              <div>
                <span>{isDisposition ? "Prise en charge" : "Départ"}</span>
                <strong>{form.pickupAddress}</strong>
              </div>
              {isDisposition ? (
                <>
                  <div>
                    <span>Durée estimée</span>
                    <strong>{durationHours} heure{durationHours > 1 ? "s" : ""}</strong>
                  </div>
                  <div>
                    <span>Nombre de passagers</span>
                    <strong>{passengerCount} passager{passengerCount > 1 ? "s" : ""}</strong>
                  </div>
                  <div>
                    <span>Programme détaillé</span>
                    <strong className="summary-program">{form.quoteDetails}</strong>
                  </div>
                </>
              ) : (
                <div>
                  <span>Destination</span>
                  <strong>{form.dropoffAddress}</strong>
                </div>
              )}
              <div className="summary-row">
                <span>{formatDate(form.pickupDate)} · {form.pickupTime}</span>
                <strong>Tesla Model Y · Noire Premium</strong>
              </div>
              <div className="summary-cancellation-row">
                <span>Conditions d’annulation</span>
                <strong className="text-cancellation-free">Sans frais jusqu’à 1h avant la prise en charge</strong>
              </div>
              <div>
                <span>{isQuoteConfirmation ? "Tarif" : "Statut Règlement"}</span>
                <strong>
                  {isQuoteConfirmation
                    ? "À convenir directement avec N LEON"
                    : confirmation.paymentStatus === "paid"
                      ? "Payé par PayPal / Carte bancaire"
                      : "À régler à bord auprès du chauffeur"}
                </strong>
              </div>
              {!isQuoteConfirmation && (
                <div className="summary-price">
                  <span>{confirmation.paymentStatus === "paid" ? "Montant réglé" : "Montant garanti"}</span>
                  <strong>{money.format(confirmation.totalPrice)}</strong>
                </div>
              )}
            </div>
            <p className="reference">
              Référence {isQuoteConfirmation ? "demande" : "réservation"} · {confirmation.bookingId.slice(0, 8).toUpperCase()}
              {confirmation.captureId ? <> · Réf. PayPal · {confirmation.captureId.slice(0, 12).toUpperCase()}</> : null}
            </p>
            <button className="button button-gold modal-button" type="button" onClick={() => setConfirmation(null)}>
              Parfait, merci <ArrowRight size={18} />
            </button>
          </section>
        </div>
      )}
    </main>
  );
}
